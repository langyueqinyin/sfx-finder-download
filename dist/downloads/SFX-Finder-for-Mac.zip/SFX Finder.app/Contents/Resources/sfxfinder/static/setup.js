'use strict';

// 首次引导。接收方拿到的是同一个共享库，只是各自放在不同盘、不同路径下，
// 所以只要认出「这确实是那个库」就行，剩下的全自动。

const setupState = { path: '', info: null, busy: false };

function setupCard() { return document.getElementById('setupCard'); }

function showSetup() {
  document.getElementById('setup').classList.remove('hidden');
  renderSetup();
}

function hideSetup() {
  document.getElementById('setup').classList.add('hidden');
}

function renderSetup() {
  const card = setupCard();
  card.innerHTML = '';
  card.append(el('h2', null, t('setup.title')));
  card.append(el('p', 'setup-intro', t('setup.intro')));

  const row = el('div', 'rowflex');
  const pick = el('button', 'primary', t('setup.pick'));
  pick.onclick = async () => {
    const j = await jpost('/api/choose-folder', { prompt: t('setup.pick') });
    if (j.path) { setupState.path = j.path; inspectPath(); }
    else if (!j.native) toast(t('setup.winHint'), 4000);
  };
  const input = el('input');
  input.type = 'text';
  input.placeholder = t('setup.pathPh');
  input.value = setupState.path || '';
  input.onkeydown = (e) => {
    if ((KEY_ALIAS[e.key] || e.key) === 'Enter') { setupState.path = input.value.trim(); inspectPath(); }
  };
  const check = el('button', null, t('setup.check'));
  check.onclick = () => { setupState.path = input.value.trim(); inspectPath(); };
  row.append(pick, input, check);
  card.append(row);

  if (setupState.busy) {
    card.append(el('div', 'setup-status', t('setup.checking')));
    return;
  }

  const info = setupState.info;
  if (!info) return;

  const box = el('div', 'setup-result');
  if (!info.ok) {
    box.classList.add('bad');
    box.append(el('div', null,
      info.err === 'dir_missing' ? t('setup.dirMissing') : t('setup.noAudio')));
    box.append(el('div', 'setup-path', info.path));
    card.append(box);
    return;
  }

  box.append(el('div', 'setup-path', info.path));
  box.append(el('div', 'setup-ok', info.truncated
    ? t('setup.foundAudioMore', info.n_audio.toLocaleString())
    : t('setup.foundAudio', info.n_audio.toLocaleString())));
  if (info.catalogs.length) {
    box.append(el('div', 'setup-ok', t('setup.foundCatalog', info.catalogs[0].rel)));
  } else {
    box.append(el('div', 'setup-warn', t('setup.noCatalog')));
  }
  if (info.top_dirs.length) {
    box.append(el('div', 'setup-dim', t('setup.topDirs', info.top_dirs.join(' · '))));
  }
  card.append(box);

  const acts = el('div', 'modal-actions');
  const again = el('button', 'ghost', t('setup.again'));
  again.onclick = () => { setupState.info = null; renderSetup(); };
  const go = el('button', 'primary', t('setup.confirm'));
  go.onclick = () => {
    if (setupState.applying) return;      // 双击会发两次 apply，第二次会清空刚建的索引
    setupState.applying = true;
    go.disabled = true;
    applySetup(info.path);
  };
  acts.append(again, go);
  card.append(acts);
}

async function inspectPath() {
  if (!setupState.path) return;
  setupState.busy = true;
  setupState.info = null;
  renderSetup();
  try {
    setupState.info = await api('/api/setup/inspect', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: setupState.path }),
    });
  } catch (e) {
    setupState.info = { ok: false, err: 'dir_missing', path: setupState.path };
  }
  setupState.busy = false;
  renderSetup();
}

async function applySetup(path) {
  const card = setupCard();
  card.innerHTML = '';
  card.append(el('h2', null, t('setup.building')));
  card.append(el('p', 'setup-intro', t('setup.buildNote')));
  const bar = el('div', 'setup-progress');
  const fill = el('div', 'setup-progress-fill');
  bar.append(fill);
  card.append(bar);
  const status = el('div', 'setup-status', '');
  card.append(status);

  try {
    await jpost('/api/setup/apply', { path });
  } catch (e) {
    card.innerHTML = '';
    card.append(el('h2', null, t('setup.title')));
    card.append(el('div', 'setup-result bad', e.message));
    const again = el('button', 'primary', t('setup.again'));
    again.onclick = () => { setupState.info = null; renderSetup(); };
    card.append(again);
    return;
  }

  // 轮询后台索引任务，完成后自动进搜索界面
  const steps = { walking: 0.35, catalog: 0.75, terms: 0.92, done: 1 };
  const tick = async () => {
    let s;
    try { s = await api('/api/status'); } catch { setTimeout(tick, 1200); return; }
    const msg = s.job && s.job.msg;
    if (msg) {
      status.textContent = t('job.' + msg);
      fill.style.width = `${(steps[msg] || 0.2) * 100}%`;
    }
    if (s.job && s.job.running) { setTimeout(tick, 1000); return; }
    fill.style.width = '100%';
    hideSetup();
    await bootAfterSetup();
  };
  tick();
}

async function bootAfterSetup() {
  const sel = document.getElementById('library');
  sel.length = 1;
  try {
    const f = await api('/api/facets');
    f.libraries.forEach((l) => sel.append(new Option(`${libName(l.library)} (${l.n})`, l.library)));
  } catch {}
  loadStatus();
  loadCart();
  render();
  document.getElementById('q').focus();
}
