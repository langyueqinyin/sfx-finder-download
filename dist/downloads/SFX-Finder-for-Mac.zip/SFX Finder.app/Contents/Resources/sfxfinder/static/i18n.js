'use strict';

// 界面文案。加语言就在这里加一块，然后在 LANGS 里登记。
const I18N = {
  zh: {
    'nav.rescan': '重扫索引',
    'search.ph': '搜音效…  试试 glass break / rattle / 动物 / SI-4001',
    'filter.allLibs': '全部库', 'filter.allExt': '全部格式', 'filter.allDur': '全部时长',
    'filter.dur1': '≤ 2 秒', 'filter.dur2': '2–10 秒', 'filter.dur3': '10 秒–1 分', 'filter.dur4': '＞ 1 分',
    'filter.autoplay': '连播',
    'sort.rel': '按相关度', 'sort.dur': '按时长', 'sort.name': '按文件名',

    'hint.move': '移动', 'hint.spaceKey': '空格', 'hint.play': '试听 / 暂停', 'hint.stop': '停止',
    'hint.select': '选中', 'hint.selectNext': '选中并跳下一条', 'hint.focus': '回到搜索框',

    'res.empty': '输入关键词开始搜索',
    'res.none': '没找到 “{0}”',
    'res.meta': '{0} 条结果{1}，显示 {2} 条',
    'res.merged': '（已并入 {0}）',
    'res.more': '再加载 {0} 条',
    'res.reveal': '在访达中显示',
    'res.approxDur': '时长来自对照表，比实际略短 1–3 秒',
    'res.expand': '还有 {0} 条同样描述的其他版本，点开逐条试听',
    'res.collapse': '收起这 {0} 条',
    'res.collapseLabel': '收起',
    'lib.root': '（库根目录）',

    'setup.title': '第一次使用：告诉我素材库在哪',
    'setup.intro': '选中你存放共享 SFX 素材库的那个文件夹。库里面的结构大家都一样，认出来之后剩下的全自动。',
    'setup.pick': '选择文件夹…',
    'setup.pathPh': '或者直接把路径粘在这里',
    'setup.check': '检查这个文件夹',
    'setup.checking': '正在看这个文件夹…',
    'setup.foundAudio': '找到 {0} 个音频文件',
    'setup.foundAudioMore': '找到 {0}+ 个音频文件（只数了前面一部分，建库时才数得准）',
    'setup.foundCatalog': '找到对照表：{0}',
    'setup.noCatalog': '没找到对照表——还是能用，搜索会靠文件名和目录名',
    'setup.topDirs': '里面有：{0}',
    'setup.noAudio': '这个文件夹里没有音频文件，是不是选到上一级或者下一级了？',
    'setup.dirMissing': '这个路径不存在',
    'setup.confirm': '就是它，建立索引',
    'setup.again': '重选',
    'setup.building': '正在建立索引…',
    'setup.buildNote': '遍历目录一两分钟，之后读对照表。不用一直等着，建好会自动进搜索界面。',
    'setup.reconfigure': '重新指定素材库',
    'setup.winHint': 'Windows 上如果没弹出选择框，把路径粘在下面的输入框里。',

    'relax.note': '没有完全匹配的结果，已放宽搜索',
    'relax.used': '{0} → {1}',
    'relax.dropped': '忽略了 {0}',
    'relax.exact': '只看精确匹配',

    'sug.terms': '相关词', 'sug.cats': '细分类型',
    'sug.plus': '并入当前结果一起看',
    'sug.merged': '并入 “{0}” 的 {1} 条新结果',

    'cart.selected': '已选', 'cart.items': '条', 'cart.clear': '清空',
    'cart.copy': '拷贝到项目文件夹…',
    'cart.empty': '勾选结果后会出现在这里',

    'copy.title': '拷贝 {0} 条到项目文件夹',
    'copy.dest': '目标文件夹', 'copy.pick': '选择…', 'copy.recent': '最近用过的…',
    'copy.subfolder': '自动建子文件夹（按搜索词）',
    'copy.enable': '启用', 'copy.subPh': '不填就直接拷到目标文件夹',
    'copy.naming': '文件命名', 'copy.nameDesc': '描述_原名', 'copy.nameOrig': '保持原名',
    'copy.tree': '保留原来的子目录结构',
    'copy.suffix': '重名时加后缀 _2', 'copy.skip': '重名时跳过',
    'copy.clearCart': '拷完清空篮子',
    'copy.cancel': '取消', 'copy.go': '开始拷贝', 'copy.going': '拷贝中…',
    'copy.noDest': '（未选目标）',
    'copy.doneTitle': '拷贝完成',
    'copy.ok': '成功 {0} 条', 'copy.skipped': '跳过 {0} 条（重名）', 'copy.failed': '失败 {0} 条',
    'copy.target': '目标', 'copy.problems': '有问题的条目',
    'copy.openFinder': '在访达中打开', 'copy.done': '好',
    'copy.error': '拷贝失败：{0}',

    'vol.unmounted': '未挂载', 'vol.swap': '换盘…',
    'vol.pillHint': '点一下可以换盘或重新指定素材库',
    'vol.title': '{0} — 换盘 / 换素材库',
    'vol.explain': '索引里存的都是相对路径，换盘只改卷名，{0} 条索引不用重建。',
    'vol.found': '在这些卷里找到了一样的目录结构',
    'vol.none': '没有任何已挂载的卷里有 {0}',
    'vol.switchTo': '切到 {0}', 'vol.verified': '（已校验）',
    'vol.unverified': '（结构对得上，但没找到标志文件）',
    'vol.switched': '已切换到 {0}',
    'vol.close': '关闭',

    'health.title': '坏账报告',
    'health.scanning': '扫描中…',
    'health.ok': '可用素材', 'health.zero': '0 字节空壳',
    'health.unsupported': '放不了的老格式', 'health.unsupportedNote': 'SDII .L/.R 拆分立体声',
    'health.missing': '索引后消失',
    'health.secZero': '0 字节空壳文件', 'health.secUnsupported': '放不了的老格式',
    'health.secBins': '只有 Avid bin、没有真音频的目录', 'health.secEmpty': '空目录',
    'health.secMissing': '索引后消失的文件',
    'health.gotIt': '知道了',

    'job.rescan': '已在后台重扫索引，完成后刷新页面即可',
    'job.running': '后台任务：{0}',
    'play.error': '放不了：{0}',
    'play.broken': '这条放不了，可能源文件已损坏',

    // 服务端错误
    'err.no_dest': '没填目标文件夹',
    'err.dest_missing': '目标文件夹不存在：{0}',
    'err.cart_empty': '篮子是空的',
    'err.src_missing': '源文件不在了（盘没挂载？）',
    'err.not_indexed': '索引里找不到这条',
    'err.name_exists': '同名文件已存在',
    'err.transcode_failed': '转码失败',
    'err.no_volume': '没指定卷',
    'err.busy': '已经有一个索引任务在跑了，等它完成',
    'err.not_found': '找不到这条',
    'job.walking': '遍历目录…', 'job.catalog': '读对照表…',
    'job.terms': '建词表…', 'job.done': '完成', 'job.paused': '已暂停',
  },

  en: {
    'nav.rescan': 'Re-index',
    'search.ph': 'Search sound effects…  try glass break / rattle / horse gallop / SI-4001',
    'filter.allLibs': 'All libraries', 'filter.allExt': 'All formats', 'filter.allDur': 'Any length',
    'filter.dur1': '≤ 2 s', 'filter.dur2': '2–10 s', 'filter.dur3': '10 s – 1 min', 'filter.dur4': '> 1 min',
    'filter.autoplay': 'Auto-play',
    'sort.rel': 'By relevance', 'sort.dur': 'By length', 'sort.name': 'By filename',

    'hint.move': 'move', 'hint.spaceKey': 'Space', 'hint.play': 'play / pause', 'hint.stop': 'stop',
    'hint.select': 'select', 'hint.selectNext': 'select & next', 'hint.focus': 'back to search',

    'res.empty': 'Type a keyword to start searching',
    'res.none': 'Nothing found for “{0}”',
    'res.meta': '{0} results{1}, showing {2}',
    'res.merged': ' (merged in {0})',
    'res.more': 'Load {0} more',
    'res.reveal': 'Reveal in Finder',
    'res.approxDur': 'Length comes from the catalog sheet — runs 1–3 s short of the real file',
    'res.expand': '{0} more takes share this description — expand to audition them',
    'res.collapse': 'Collapse these {0}',
    'res.collapseLabel': 'collapse',
    'lib.root': '(library root)',

    'setup.title': 'Choose your sound library folder',
    'setup.intro': 'Choose one folder containing your sound effects. Nested folders are indexed automatically, and no catalog spreadsheet is required.',
    'setup.pick': 'Choose folder…',
    'setup.pathPh': 'or paste the path here',
    'setup.check': 'Check this folder',
    'setup.checking': 'Looking inside…',
    'setup.foundAudio': 'Found {0} audio files',
    'setup.foundAudioMore': 'Found {0}+ audio files (only counted the first batch — the real number comes from indexing)',
    'setup.foundCatalog': 'Catalog detected — descriptions will be added automatically: {0}',
    'setup.topDirs': 'Contains: {0}',
    'setup.noAudio': 'No audio files in this folder — did you pick one level too high or too low?',
    'setup.dirMissing': 'That path does not exist',
    'setup.confirm': 'That is the one — build the index',
    'setup.again': 'Pick again',
    'setup.building': 'Building the index…',
    'setup.buildNote': 'Walking nested folders may take a minute or two. Optional catalog descriptions are added automatically. The search screen opens when indexing is done.',
    'setup.reconfigure': 'Point at a different library',
    'setup.winHint': 'On Windows, if no dialog appears, paste the path into the box below.',

    'relax.note': 'No exact match — search was widened',
    'relax.used': '{0} → {1}',
    'relax.dropped': 'ignored {0}',
    'relax.exact': 'Exact match only',

    'sug.terms': 'Related', 'sug.cats': 'Narrow by',
    'sug.plus': 'Merge into current results',
    'sug.merged': 'Merged in {1} new results for “{0}”',

    'cart.selected': 'Selected', 'cart.items': '', 'cart.clear': 'Clear',
    'cart.copy': 'Copy to project folder…',
    'cart.empty': 'Ticked results show up here',

    'copy.title': 'Copy {0} files to project folder',
    'copy.dest': 'Destination folder', 'copy.pick': 'Choose…', 'copy.recent': 'Recently used…',
    'copy.subfolder': 'Auto-create subfolder (from search term)',
    'copy.enable': 'On', 'copy.subPh': 'Leave empty to copy straight into the destination',
    'copy.naming': 'File naming', 'copy.nameReadable': 'Use readable descriptions', 'copy.nameOrig': 'Keep original filenames',
    'copy.partialDescriptions': '{0} of {1} clips have readable descriptions. The remaining {2} will keep their original filenames.',
    'copy.tree': 'Preserve original subfolder structure',
    'copy.suffix': 'On conflict: add _2', 'copy.skip': 'On conflict: skip',
    'copy.clearCart': 'Clear basket when done',
    'copy.cancel': 'Cancel', 'copy.go': 'Copy', 'copy.going': 'Copying…',
    'copy.noDest': '(no destination yet)',
    'copy.doneTitle': 'Copy finished',
    'copy.ok': '{0} copied', 'copy.skipped': '{0} skipped (name clash)', 'copy.failed': '{0} failed',
    'copy.target': 'Destination', 'copy.problems': 'Problem files',
    'copy.openFinder': 'Open in Finder', 'copy.done': 'Done',
    'copy.error': 'Copy failed: {0}',

    'vol.unmounted': 'not mounted', 'vol.swap': 'Switch drive…',
    'vol.pillHint': 'Click to switch drive or point at a different library',
    'vol.title': '{0} — switch drive or library',
    'vol.explain': 'The index stores relative paths only, so switching drives just changes the volume name — none of the {0} indexed files need rebuilding.',
    'vol.found': 'Found the same folder structure on these volumes',
    'vol.none': 'No mounted volume contains {0}',
    'vol.switchTo': 'Switch to {0}', 'vol.verified': ' (verified)',
    'vol.unverified': ' (structure matches, but marker file missing)',
    'vol.switched': 'Switched to {0}',
    'vol.close': 'Close',

    'health.title': 'Library health',
    'health.scanning': 'Scanning…',
    'health.ok': 'usable files', 'health.zero': 'zero-byte shells',
    'health.unsupported': 'unplayable legacy format', 'health.unsupportedNote': 'SDII .L/.R split stereo',
    'health.missing': 'gone since indexing',
    'health.secZero': 'Zero-byte shell files', 'health.secUnsupported': 'Unplayable legacy formats',
    'health.secBins': 'Folders with only Avid bins, no real audio', 'health.secEmpty': 'Empty folders',
    'health.secMissing': 'Files gone since indexing',
    'health.gotIt': 'Got it',

    'job.rescan': 'Re-indexing in the background — refresh the page when it finishes',
    'job.running': 'Background job: {0}',
    'play.error': 'Cannot play: {0}',
    'play.broken': 'This one will not play — the source file may be corrupt',

    'err.no_dest': 'No destination folder',
    'err.dest_missing': 'Destination folder does not exist: {0}',
    'err.cart_empty': 'The basket is empty',
    'err.src_missing': 'Source file is gone (drive not mounted?)',
    'err.not_indexed': 'Not found in the index',
    'err.name_exists': 'A file with that name already exists',
    'err.transcode_failed': 'Transcode failed',
    'err.no_volume': 'No volume specified',
    'err.busy': 'An indexing job is already running — wait for it to finish',
    'err.not_found': 'Not found',
    'job.walking': 'Walking folders…', 'job.catalog': 'Reading catalog sheets…',
    'job.terms': 'Building term index…', 'job.done': 'Done', 'job.paused': 'Paused',
  },
};

const LANGS = ['zh', 'en'];

// UI_CONFIG 由服务端按 config.json 生成（见 /static/ui-config.js）。
// 发给英文用户的版本会锁成 en 并隐藏切换按钮，省得他们看见中文按钮发懵。
const UI = (typeof window !== 'undefined' && window.UI_CONFIG) || {};
const LANG_LOCKED = UI.lang && UI.lang !== 'auto';

let LANG = LANG_LOCKED ? UI.lang
  : (localStorage.getItem('sfx.lang')
     || (String(navigator.language || '').toLowerCase().startsWith('zh') ? 'zh' : 'en'));
if (!LANGS.includes(LANG)) LANG = 'en';

function t(key, ...args) {
  const s = (I18N[LANG] && I18N[LANG][key]) ?? I18N.en[key] ?? key;
  return s.replace(/\{(\d+)\}/g, (m, i) => (args[i] !== undefined ? args[i] : m));
}

/** 服务端回来的 {err: 'cart_empty', error: '...'}，认得就翻译，认不得就照原样显示。 */
function tErr(payload) {
  if (payload && payload.err) {
    const key = 'err.' + payload.err;
    if ((I18N[LANG] && I18N[LANG][key]) || I18N.en[key]) return t(key, ...(payload.args || []));
  }
  return (payload && payload.error) || t('err.not_found');
}

function applyI18n() {
  document.documentElement.lang = LANG === 'zh' ? 'zh-CN' : 'en';
  document.querySelectorAll('[data-i18n]').forEach((n) => {
    n.textContent = t(n.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-ph]').forEach((n) => {
    n.placeholder = t(n.dataset.i18nPh);
  });
  const btn = document.getElementById('btnLang');
  if (!btn) return;
  if (LANG_LOCKED || UI.lang_toggle === false) btn.remove();
  else btn.textContent = LANG === 'zh' ? 'EN' : '中文';
}

function setLang(lang) {
  LANG = lang;
  localStorage.setItem('sfx.lang', lang);
  applyI18n();
}
