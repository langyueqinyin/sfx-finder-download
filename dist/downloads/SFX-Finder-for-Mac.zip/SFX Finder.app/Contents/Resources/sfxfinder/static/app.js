'use strict';

const $ = (s) => document.querySelector(s);
const el = (tag, cls, txt) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (txt != null) n.textContent = txt;
  return n;
};

const state = {
  q: '',
  groups: [],      // 服务端返回的结果，同描述的已折叠成一组
  view: [],        // 摊平后真正显示的行（展开的组会把 dupes 插在自己后面）
  total: 0, offset: 0, limit: 100,
  cursor: -1, cart: new Set(), playing: null,
  merged: [],      // 用 + 并进来的相关词
  cartData: null,
};

const audio = new Audio();
audio.preload = 'none';

// ------------------------------------------------------------------ 工具

function fmtDur(ms) {
  if (ms == null) return '–:––';
  const s = Math.round(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function fmtSize(b) {
  if (b == null) return '';
  return b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB';
}

const descOf = (r) => r.catalog_desc || r.embedded_desc || null;
const libName = (lib) => lib || t('lib.root');

let toastTimer;
function toast(msg, ms = 2600) {
  const box = $('#toast');
  box.textContent = msg;
  box.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.add('hidden'), ms);
}

async function api(url, opts) {
  const r = await fetch(url, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(tErr(j));
  return j;
}

const jpost = (url, body) => api(url, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body || {}),
});
const jdel = (url, body) => api(url, {
  method: 'DELETE', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body || {}),
});

// ------------------------------------------------------------------ 搜索

function currentFilters() {
  const p = new URLSearchParams();
  p.set('q', state.q);
  const lib = $('#library').value, ext = $('#ext').value, dur = $('#dur').value;
  if (lib) p.set('library', lib);
  if (ext) p.set('ext', ext);
  if (dur) {
    const [a, b] = dur.split('-');
    if (a) p.set('dur_min', a);
    if (b) p.set('dur_max', b);
  }
  p.set('sort', $('#sort').value);
  return p;
}

let searchSeq = 0;
async function doSearch(append = false, opts = {}) {
  const seq = ++searchSeq;
  const p = currentFilters();
  p.set('limit', state.limit);
  p.set('offset', append ? state.offset : 0);
  if (opts.loose === false) p.set('loose', '0');
  const j = await api('/api/search?' + p);
  if (seq !== searchSeq) return;                 // 打字快时丢弃过期响应

  if (append) {
    state.groups = state.groups.concat(j.rows);
    state.offset += j.consumed;                  // 按原始行数推进，不是按组数
  } else {
    state.groups = j.rows;
    state.offset = j.consumed;
    state.merged = [];
    state.cursor = -1;
    state.relax = j.relax || null;
  }
  state.total = j.total;
  render();
  if (!append) loadSuggest();
}

async function mergeTerm(term) {
  const p = currentFilters();
  p.set('q', term);
  p.set('limit', 100);
  const j = await api('/api/search?' + p);
  const have = new Set(state.groups.map((r) => r.id));
  const added = j.rows.filter((r) => !have.has(r.id));
  state.groups = state.groups.concat(added);
  state.merged.push(term);
  render();
  toast(t('sug.merged', term, added.length));
}

async function loadSuggest() {
  const box = $('#suggest');
  box.innerHTML = '';
  if (!state.q) return;
  let j;
  try {
    const p = new URLSearchParams({ q: state.q });
    if ($('#library').value) p.set('library', $('#library').value);
    j = await api('/api/suggest?' + p);
  } catch { return; }
  if (state.q !== $('#q').value.trim()) return;

  if (j.terms && j.terms.length) {
    const g = el('div', 'sug-group');
    g.append(el('span', 'sug-label', t('sug.terms')));
    j.terms.forEach((x) => {
      const c = el('span', 'chip' + (x.from_dict ? ' dict' : ''));
      const name = el('span', 't', x.term);
      name.onclick = () => { $('#q').value = x.term; state.q = x.term; doSearch(); };
      const plus = el('button', 'plus', '+');
      plus.title = t('sug.plus');
      plus.onclick = () => mergeTerm(x.term);
      c.append(name, el('span', 'n', x.count), plus);
      g.append(c);
    });
    box.append(g);
  }
  if (j.categories && j.categories.length) {
    const g = el('div', 'sug-group');
    g.append(el('span', 'sug-label', t('sug.cats')));
    j.categories.forEach((c) => {
      const chip = el('span', 'chip cat');
      const name = el('span', 't', c.name);
      name.onclick = () => {
        const nq = `${state.q} ${c.name}`.trim();
        $('#q').value = nq; state.q = nq; doSearch();
      };
      chip.append(name, el('span', 'n', c.count));
      g.append(chip);
    });
    box.append(g);
  }
}

// ------------------------------------------------------------------ 渲染

/** 组 -> 摊平的显示列表。展开的组把自己的 dupes 跟在后面，收起时它们只是不参与摊平。 */
function buildView() {
  const out = [];
  state.groups.forEach((g) => {
    out.push(g);
    if (g.expanded && g.dupes) g.dupes.forEach((d) => out.push(Object.assign(d, { _child: true })));
  });
  state.view = out;
}

function render() {
  buildView();
  const list = $('#list');
  list.innerHTML = '';
  const meta = $('#resultMeta');

  if (!state.view.length) {
    meta.textContent = '';
    list.append(el('div', 'empty', state.q ? t('res.none', state.q) : t('res.empty')));
    $('#more').innerHTML = '';
    return;
  }
  const mergedNote = state.merged.length ? t('res.merged', state.merged.join(' / ')) : '';
  meta.textContent = '';
  meta.append(document.createTextNode(
    t('res.meta', state.total ?? state.view.length, mergedNote, state.view.length)));
  if (state.relax) meta.append(relaxNote(state.relax));

  state.view.forEach((r, i) => list.append(rowNode(r, i)));

  const more = $('#more');
  more.innerHTML = '';
  if (state.total > state.groups.length && !state.merged.length) {
    const n = Math.min(state.limit, state.total - state.groups.length);
    const b = el('button', 'ghost', t('res.more', n));
    b.onclick = () => doSearch(true);
    more.append(b);
  }
  probeVisible();
}

/** 放宽提示：说清楚每个词实际是拿什么去搜的、哪个词被忽略了，
 *  别让人以为这就是精确匹配。 */
function relaxNote(relax) {
  const box = el('span', 'relax');
  box.append(el('span', 'relax-tag', t('relax.note')));
  relax.used.forEach((u) => {
    const others = u.terms.filter((x) => x !== u.orig);
    if (!others.length) return;
    const chip = el('span', 'relax-sub', t('relax.used', u.orig, others.slice(0, 4).join(' / ')));
    box.append(chip);
  });
  if (relax.dropped && relax.dropped.length) {
    box.append(el('span', 'relax-drop', t('relax.dropped', relax.dropped.join(' / '))));
  }
  const exact = el('button', 'relax-exact', t('relax.exact'));
  exact.onclick = () => doSearch(false, { loose: false });
  box.append(exact);
  return box;
}

function rowNode(r, i) {
  const row = el('div', 'row' + (r._child ? ' child' : ''));
  row.dataset.i = i;
  row.dataset.id = r.id;
  if (state.cart.has(r.id)) row.classList.add('checked');
  if (i === state.cursor) row.classList.add('cursor');
  const isPlaying = state.playing === r.id;
  if (isPlaying) row.classList.add('playing');

  const cb = el('input');
  cb.type = 'checkbox';
  cb.checked = state.cart.has(r.id);
  cb.onclick = (e) => { e.stopPropagation(); toggleCart(r.id); };

  const play = el('button', 'play', isPlaying && !audio.paused ? '❚❚' : '▶');
  play.onclick = (e) => { e.stopPropagation(); togglePlay(i); };

  const info = el('div', 'info');
  const d = descOf(r);
  const desc = el('div', 'desc' + (d ? '' : ' nodesc'));
  desc.append(document.createTextNode(d || r.filename));
  desc.title = d || r.filename;

  // 同描述的其他 take。折叠是为了别让一句话刷满整屏；展开听完能再收回去。
  if (r.dupe_n > 1 || (r.expanded && r.dupes && r.dupes.length)) {
    const open = !!r.expanded;
    const n = r.dupes ? r.dupes.length + 1 : r.dupe_n;
    const badge = el('button', 'dupes' + (open ? ' open' : ''),
      open ? `▾ ${t('res.collapseLabel')}` : `×${n}`);
    badge.title = open ? t('res.collapse', n - 1) : t('res.expand', n - 1);
    badge.onclick = (e) => { e.stopPropagation(); toggleDupes(r); };
    desc.append(badge);
  }

  const meta = el('div', 'meta');
  meta.append(el('span', 'tag', libName(r.library)));
  meta.append(document.createTextNode(
    `${r.filename} · ${r.ext.slice(1)} · ${fmtSize(r.size)}` +
    (r.folder_path ? ` · ${r.folder_path}` : '')));
  info.append(desc, meta);

  if (isPlaying) info.append(progressBar(r));

  const durCls = r.duration_ms == null ? 'dur pending'
    : (r.duration_src === 'catalog' ? 'dur approx' : 'dur');
  const dur = el('span', durCls,
    (r.duration_src === 'catalog' ? '≈' : '') + fmtDur(r.duration_ms));
  if (r.duration_src === 'catalog') dur.title = t('res.approxDur');

  const rev = el('button', 'reveal', '⤴');
  rev.title = t('res.reveal');
  rev.onclick = (e) => { e.stopPropagation(); jpost('/api/reveal', { id: r.id }); };

  row.append(cb, play, info, dur, rev);
  row.onclick = () => setCursor(i, false);
  return row;
}

/** 正在播的那条底下的进度条：能看到播到哪了，点一下就跳过去。 */
function progressBar(r) {
  const wrap = el('div', 'progress');
  const bar = el('div', 'pbar');
  const time = el('span', 'ptime', '0:00');
  wrap.append(bar, time);
  wrap.onclick = (e) => {
    e.stopPropagation();
    if (!audio.duration || !isFinite(audio.duration)) return;
    const rect = wrap.getBoundingClientRect();
    audio.currentTime = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)) * audio.duration;
    paintProgress();
  };
  return wrap;
}

function paintProgress() {
  const row = $('.row.playing');
  if (!row) return;
  const bar = row.querySelector('.pbar');
  const time = row.querySelector('.ptime');
  if (!bar) return;
  const d = isFinite(audio.duration) ? audio.duration : 0;
  bar.style.width = d ? `${(audio.currentTime / d) * 100}%` : '0%';
  if (time) {
    time.textContent = d
      ? `${fmtDur(audio.currentTime * 1000)} / ${fmtDur(d * 1000)}`
      : fmtDur(audio.currentTime * 1000);
  }
}

function refreshRow(i) {
  const old = $(`.row[data-i="${i}"]`);
  if (old && state.view[i]) old.replaceWith(rowNode(state.view[i], i));
}

function refreshPlayingRow() {
  const i = state.view.findIndex((r) => r.id === state.playing);
  if (i >= 0) refreshRow(i);
  paintProgress();
}

function toggleDupes(group) {
  group.expanded = !group.expanded;
  const keepId = state.view[state.cursor] && state.view[state.cursor].id;
  render();
  if (keepId != null) {                 // 收起后光标别乱跳
    const i = state.view.findIndex((r) => r.id === keepId);
    state.cursor = i >= 0 ? i : Math.min(state.cursor, state.view.length - 1);
    render();
  }
}

// ------------------------------------------------------------------ 懒探测

let probeTimer;
function probeVisible() {
  clearTimeout(probeTimer);
  probeTimer = setTimeout(async () => {
    const box = $('#list').getBoundingClientRect();
    const need = [];
    document.querySelectorAll('.row').forEach((n) => {
      const r = state.view[+n.dataset.i];
      if (!r || r.duration_ms != null || r.probed_at != null) return;
      const b = n.getBoundingClientRect();
      if (b.bottom > box.top - 200 && b.top < box.bottom + 400) need.push(r.id);
    });
    if (!need.length) return;
    const j = await jpost('/api/probe', { ids: need.slice(0, 120) });
    const byId = new Map(j.rows.map((x) => [x.id, x]));
    let touched = false;
    state.view.forEach((r, i) => {
      const u = byId.get(r.id);
      if (!u) return;
      Object.assign(r, u);
      refreshRow(i);
      touched = true;
    });
    if (touched) paintProgress();
  }, 140);
}

$('#list').addEventListener('scroll', probeVisible);

// ------------------------------------------------------------------ 播放

// aiff 等非原生格式要 ffmpeg 转一遍才能在浏览器里放，冷启动约 2 秒。
// 光标一落到某行就先把它和下一行预热成缓存，按空格时就是秒开。
const NATIVE = new Set(['.mp3', '.wav', '.flac', '.m4a', '.ogg']);
const warmed = new Set();
function warmup(i) {
  [i, i + 1].forEach((k) => {
    const r = state.view[k];
    if (!r || NATIVE.has(r.ext) || warmed.has(r.id)) return;
    warmed.add(r.id);
    fetch(`/api/audio/${r.id}`, { headers: { Range: 'bytes=0-1' } }).catch(() => {});
  });
}

function togglePlay(i) {
  const r = state.view[i];
  if (!r) return;
  if (state.playing === r.id) {
    // 同一条：暂停 / 从暂停处继续，不要重设 src（重设会从头开始）
    if (audio.paused) audio.play().catch(() => {});
    else audio.pause();
    refreshPlayingRow();
    return;
  }
  state.playing = r.id;
  audio.src = `/api/audio/${r.id}`;
  audio.currentTime = 0;
  audio.play().catch((e) => toast(t('play.error', e.message)));
  render();
}

function stopPlay() {
  if (state.playing == null) return false;
  audio.pause();
  const was = state.playing;
  state.playing = null;
  const i = state.view.findIndex((r) => r.id === was);
  if (i >= 0) refreshRow(i);
  return true;
}

audio.addEventListener('timeupdate', paintProgress);
audio.addEventListener('play', refreshPlayingRow);
audio.addEventListener('pause', refreshPlayingRow);
audio.addEventListener('ended', () => {
  if (!$('#autoplay').checked) { stopPlay(); return; }
  if (state.cursor + 1 < state.view.length) setCursor(state.cursor + 1, true);
  else stopPlay();
});
audio.addEventListener('error', () => { if (audio.src) toast(t('play.broken')); });

function setCursor(i, play) {
  if (i < 0 || i >= state.view.length) return;
  state.cursor = i;
  render();
  const n = $(`.row[data-i="${i}"]`);
  if (n) n.scrollIntoView({ block: 'nearest' });
  warmup(i);
  if (play || $('#autoplay').checked) togglePlay(i);
}

// ------------------------------------------------------------------ 篮子

async function toggleCart(id) {
  if (state.cart.has(id)) {
    state.cart.delete(id);
    await jdel('/api/cart', { ids: [id] });
  } else {
    state.cart.add(id);
    await jpost('/api/cart', { ids: [id], query: state.q });
  }
  render();
  loadCart();
}

async function loadCart() {
  const j = await api('/api/cart');
  state.cart = new Set(j.rows.map((r) => r.id));
  state.cartData = j;
  $('#cartN').textContent = j.rows.length;
  $('#btnCopy').disabled = !j.rows.length;
  const box = $('#cartList');
  box.innerHTML = '';
  if (!j.rows.length) {
    box.append(el('div', 'cart-empty', t('cart.empty')));
    return;
  }
  j.rows.forEach((r) => {
    const it = el('div', 'cart-item');
    const n = el('span', 'n', descOf(r) || r.filename);
    n.title = `${descOf(r) || ''}\n${r.filename}`;
    const x = el('button', 'x', '×');
    x.onclick = async () => {
      await jdel('/api/cart', { ids: [r.id] });
      state.cart.delete(r.id);
      render(); loadCart();
    };
    it.append(n, el('span', 'dur', fmtDur(r.duration_ms)), x);
    box.append(it);
  });
}

$('#btnClearCart').onclick = async () => {
  await jdel('/api/cart', { all: true });
  state.cart.clear(); render(); loadCart();
};

// ------------------------------------------------------------------ 弹窗 / 拷贝

function openModal(build) {
  const body = $('#modalBody');
  body.innerHTML = '';
  build(body);
  $('#modal').classList.remove('hidden');
}
function closeModal() { $('#modal').classList.add('hidden'); }
$('#modal').onclick = (e) => { if (e.target.id === 'modal') closeModal(); };

$('#btnCopy').onclick = () => {
  const cd = state.cartData;
  openModal((body) => {
    body.append(el('h2', null, t('copy.title', cd.rows.length)));

    const f1 = el('div', 'field');
    f1.append(el('label', null, t('copy.dest')));
    const r1 = el('div', 'rowflex');
    const dest = el('input');
    dest.type = 'text';
    dest.value = cd.last_dest || '';
    const pick = el('button', null, t('copy.pick'));
    pick.onclick = async () => {
      const j = await jpost('/api/choose-folder');
      if (j.path) dest.value = j.path;
      updatePreview();
    };
    r1.append(dest, pick);
    f1.append(r1);
    if (cd.recent_dests.length) {
      const sel = el('select');
      sel.append(new Option(t('copy.recent'), ''));
      cd.recent_dests.forEach((d) => sel.append(new Option(d, d)));
      sel.onchange = () => { if (sel.value) { dest.value = sel.value; updatePreview(); } };
      sel.style.cssText = 'margin-top:6px;width:100%';
      f1.append(sel);
    }
    body.append(f1);

    const f2 = el('div', 'field');
    f2.append(el('label', null, t('copy.subfolder')));
    const r2 = el('div', 'rowflex');
    const useSub = el('input'); useSub.type = 'checkbox'; useSub.checked = !!cd.suggested_folder;
    const sub = el('input'); sub.type = 'text';
    sub.value = cd.suggested_folder || '';
    sub.placeholder = t('copy.subPh');
    const lbl = el('label', 'chk');
    lbl.append(useSub, document.createTextNode(t('copy.enable')));
    r2.append(lbl, sub);
    f2.append(r2);
    body.append(f2);

    const f3 = el('div', 'field');
    f3.append(el('label', null, t('copy.naming')));
    const radios = el('div', 'radios');
    [['desc_orig', t('copy.nameDesc')], ['orig', t('copy.nameOrig')]].forEach(([v, label]) => {
      const l = el('label');
      const inp = el('input');
      inp.type = 'radio'; inp.name = 'naming'; inp.value = v;
      inp.checked = (cd.naming_mode || 'desc_orig') === v;
      inp.onchange = updatePreview;
      l.append(inp, document.createTextNode(label));
      radios.append(l);
    });
    f3.append(radios);
    const prev = el('div', 'preview-name');
    f3.append(prev);
    body.append(f3);

    const f4 = el('div', 'field');
    const opts = el('div', 'radios');
    const tree = el('input'); tree.type = 'checkbox';
    const l1 = el('label'); l1.append(tree, document.createTextNode(t('copy.tree')));
    const conf = el('select');
    conf.append(new Option(t('copy.suffix'), 'suffix'), new Option(t('copy.skip'), 'skip'));
    const clear = el('input'); clear.type = 'checkbox'; clear.checked = true;
    const l2 = el('label'); l2.append(clear, document.createTextNode(t('copy.clearCart')));
    opts.append(l1, conf, l2);
    f4.append(opts);
    body.append(f4);

    function updatePreview() {
      const mode = body.querySelector('input[name=naming]:checked').value;
      const r = cd.rows[0];
      const d = descOf(r);
      const stem = r.filename.replace(/\.[^.]+$/, '');
      // 和后端 copier.safe_component 保持一致，预览才不会骗人
      const safe = (s) => s.replace(/[/\\:*?"<>|;,.\x00-\x1f]/g, ' ').trim()
        .replace(/\s+/g, '_').replace(/_{2,}/g, '_')
        .replace(/^[._-]+|[._-]+$/g, '').slice(0, 110);
      const name = (mode === 'desc_orig' && d) ? `${safe(d)}__${stem}${r.ext}` : r.filename;
      const dir = [dest.value || t('copy.noDest'), useSub.checked && sub.value ? sub.value : null]
        .filter(Boolean).join('/');
      prev.textContent = `${dir}/${name}`;
    }
    useSub.onchange = updatePreview;
    sub.oninput = updatePreview;
    dest.oninput = updatePreview;
    updatePreview();

    const acts = el('div', 'modal-actions');
    const cancel = el('button', 'ghost', t('copy.cancel'));
    cancel.onclick = closeModal;
    const go = el('button', 'primary', t('copy.go'));
    go.onclick = async () => {
      go.disabled = true; go.textContent = t('copy.going');
      try {
        const rep = await jpost('/api/copy', {
          dest_root: dest.value,
          subfolder: useSub.checked ? sub.value : '',
          naming_mode: body.querySelector('input[name=naming]:checked').value,
          preserve_tree: tree.checked,
          on_conflict: conf.value,
          clear_cart: clear.checked,
        });
        showReport(rep);
        loadCart(); render();
      } catch (e) {
        toast(t('copy.error', e.message));
        go.disabled = false; go.textContent = t('copy.go');
      }
    };
    acts.append(cancel, go);
    body.append(acts);
    setTimeout(() => dest.focus(), 30);
  });
};

function showReport(rep) {
  openModal((body) => {
    body.append(el('h2', null, t('copy.doneTitle')));
    body.append(el('div', 'report-line', t('copy.ok', rep.n_ok)));
    if (rep.n_skip) body.append(el('div', 'report-line skip', t('copy.skipped', rep.n_skip)));
    if (rep.n_fail) body.append(el('div', 'report-line fail', t('copy.failed', rep.n_fail)));
    body.append(el('h3', null, t('copy.target')));
    body.append(el('div', 'preview-name', rep.dest_dir));
    const bad = rep.detail.filter((d) => d.result !== 'ok');
    if (bad.length) {
      body.append(el('h3', null, t('copy.problems')));
      bad.slice(0, 30).forEach((d) => body.append(
        el('div', 'report-line ' + d.result, `${d.name || d.id} — ${tErr(d)}`)));
    }
    const acts = el('div', 'modal-actions');
    const open = el('button', null, t('copy.openFinder'));
    open.onclick = () => jpost('/api/reveal', { path: rep.dest_dir });
    const ok = el('button', 'primary', t('copy.done'));
    ok.onclick = closeModal;
    acts.append(open, ok);
    body.append(acts);
  });
}

// ------------------------------------------------------------------ 状态 / 换盘 / 健康

async function loadStatus() {
  const j = await api('/api/status');
  const box = $('#rootStatus');
  box.innerHTML = '';
  j.roots.forEach((r) => {
    // 整个 pill 随时可点开换盘/换库。以前只在盘掉线时才给按钮，
    // 结果一切正常时反而没有任何入口去指向别的目录。
    const pill = el('span', 'pill clickable' + (r.mounted ? '' : ' off'));
    pill.title = t('vol.pillHint');
    pill.onclick = () => openRepoint(r);
    pill.append(el('span', 'dot'));
    pill.append(document.createTextNode(
      `${r.label} · ${r.volume}` +
      (r.mounted ? ` · ${r.n_assets.toLocaleString()}` : ` · ${t('vol.unmounted')}`)));
    if (!r.mounted) pill.append(el('span', 'pill-cta', t('vol.swap')));
    box.append(pill);
  });
  if (j.job && j.job.running) {
    setTimeout(loadStatus, 1500);
    const msg = j.job.msg && I18N[LANG]['job.' + j.job.msg] ? t('job.' + j.job.msg) : (j.job.msg || j.job.kind);
    toast(t('job.running', msg), 1400);
  }
}

async function openRepoint(root) {
  const j = await api(`/api/roots/${root.id}/candidates`);
  openModal((body) => {
    body.append(el('h2', null, t('vol.title', root.label)));
    body.append(el('div', 'report-line', t('vol.explain', root.n_assets.toLocaleString())));
    body.append(el('h3', null, t('vol.found')));
    if (!j.candidates.length) {
      body.append(el('div', 'report-line fail', t('vol.none', root.rel_root)));
    }
    j.candidates.forEach((c) => {
      const line = el('div', 'field');
      const b = el('button', c.verified ? 'primary' : '',
        t('vol.switchTo', c.volume) + (c.verified ? t('vol.verified') : t('vol.unverified')));
      b.onclick = async () => {
        await jpost(`/api/roots/${root.id}/repoint`, { base_path: c.base_path });
        closeModal(); loadStatus(); toast(t('vol.switched', c.volume));
      };
      line.append(b);
      body.append(line);
    });
    const acts = el('div', 'modal-actions');
    const close = el('button', 'ghost', t('vol.close'));
    close.onclick = closeModal;
    const redo = el('button', 'primary', t('setup.reconfigure'));
    redo.onclick = () => { closeModal(); setupState.info = null; setupState.applying = false; showSetup(); };
    acts.append(close, redo);
    body.append(acts);
  });
}

$('#btnHealth').onclick = async () => {
  openModal((b) => {
    b.append(el('h2', null, t('health.title')));
    b.append(el('div', 'report-line', t('health.scanning')));
  });
  const j = await api('/api/health');
  openModal((body) => {
    body.append(el('h2', null, t('health.title')));
    const sum = el('div', 'health-sum');
    [[t('health.ok'), j.totals.ok, ''],
     [t('health.zero'), j.totals.zero_byte, ''],
     [t('health.unsupported'), j.totals.unsupported, t('health.unsupportedNote')],
     [t('health.missing'), j.totals.missing, '']].forEach(([label, n, note]) => {
      const d = el('div');
      d.append(el('b', null, (n || 0).toLocaleString()),
               el('span', null, label + (note ? ` · ${note}` : '')));
      sum.append(d);
    });
    body.append(sum);

    const section = (title, rows, cols) => {
      if (!rows || !rows.length) return;
      body.append(el('h3', null, title));
      const tbl = el('table', 'health');
      rows.slice(0, 25).forEach((r) => {
        const tr = el('tr');
        tr.append(el('td', null, cols(r)));
        tr.append(el('td', 'n', String(r.n ?? r.bins ?? '')));
        tbl.append(tr);
      });
      body.append(tbl);
    };
    section(t('health.secZero'), j.zero_byte, (r) => r.folder_path || r.library);
    section(t('health.secUnsupported'), j.unsupported, (r) => r.folder_path || r.library);
    section(t('health.secBins'), j.bin_only_dirs, (r) => `${r.root} / ${r.path}`);
    section(t('health.secEmpty'), j.empty_dirs, (r) => `${r.root} / ${r.path}`);
    section(t('health.secMissing'), j.missing, (r) => r.folder_path || r.library);

    const acts = el('div', 'modal-actions');
    const ok = el('button', 'primary', t('health.gotIt'));
    ok.onclick = closeModal;
    acts.append(ok);
    body.append(acts);
  });
};

$('#btnRescan').onclick = async () => {
  $('#btnRescan').disabled = true;
  try {
    await jpost('/api/index/rescan');
    toast(t('job.rescan'));
    loadStatus();
  } finally {
    setTimeout(() => { $('#btnRescan').disabled = false; }, 3000);
  }
};

$('#btnLang').onclick = () => {
  setLang(LANG === 'zh' ? 'en' : 'zh');
  render();
  loadCart();
  loadStatus();
  loadSuggest();
};

// ------------------------------------------------------------------ 键盘

// 少数环境（远程桌面、自动化注入）送来的是老式键名 Down/Up 而不是 ArrowDown/ArrowUp
const KEY_ALIAS = { Down: 'ArrowDown', Up: 'ArrowUp', Esc: 'Escape', Spacebar: ' ' };

document.addEventListener('keydown', (e) => {
  const key = KEY_ALIAS[e.key] || e.key;
  const inField = ['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName);

  if (key === '/' && !inField) { e.preventDefault(); $('#q').focus(); $('#q').select(); return; }
  if (key === 'Escape') {
    if (!$('#modal').classList.contains('hidden')) { closeModal(); return; }
    if (stopPlay()) { e.preventDefault(); return; }   // 播着就先停播放
    if (inField) { e.target.blur(); return; }
  }
  if (inField && e.target.id === 'q') {
    if (key === 'ArrowDown') { e.preventDefault(); $('#q').blur(); setCursor(0, false); }
    return;
  }
  if (inField || !$('#modal').classList.contains('hidden')) return;

  if (key === 'ArrowDown') { e.preventDefault(); setCursor(state.cursor + 1, false); }
  else if (key === 'ArrowUp') { e.preventDefault(); setCursor(Math.max(0, state.cursor - 1), false); }
  else if (key === ' ') { e.preventDefault(); if (state.cursor >= 0) togglePlay(state.cursor); }
  else if (key === 'ArrowLeft' && state.playing != null) {
    e.preventDefault(); audio.currentTime = Math.max(0, audio.currentTime - 2);
  } else if (key === 'ArrowRight' && state.playing != null) {
    e.preventDefault(); audio.currentTime = audio.currentTime + 2;
  } else if (key === 'Enter') {
    e.preventDefault();
    const r = state.view[state.cursor];
    if (!r) return;
    toggleCart(r.id);
    if (e.metaKey || e.ctrlKey) setCursor(state.cursor + 1, false);
  }
});

// ------------------------------------------------------------------ 启动

let typeTimer;
$('#q').addEventListener('input', () => {
  clearTimeout(typeTimer);
  typeTimer = setTimeout(() => {
    state.q = $('#q').value.trim();
    doSearch();
  }, 220);
});
['library', 'ext', 'dur', 'sort'].forEach((id) => {
  $('#' + id).addEventListener('change', () => doSearch());
});

// 等 DOM 和 setup.js 都就位再启动——引导流程定义在 setup.js 里
window.addEventListener('DOMContentLoaded', async () => {
  applyI18n();

  let st;
  try { st = await api('/api/setup/state'); } catch { st = { needs_setup: false }; }
  if (st.needs_setup) { showSetup(); return; }   // 还没配库，先走引导

  try {
    const f = await api('/api/facets');
    const sel = $('#library');
    f.libraries.forEach((l) => sel.append(new Option(`${libName(l.library)} (${l.n})`, l.library)));
  } catch {}
  loadStatus();
  loadCart();
  render();          // 先把空状态提示画出来，别让人对着一片黑
  $('#q').focus();
});
