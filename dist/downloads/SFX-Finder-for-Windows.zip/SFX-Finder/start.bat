@echo off
REM Windows: double-click this file to start SFX Finder.
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo First run - installing dependencies...
  python -m venv .venv
  if errorlevel 1 (
    echo Could not create a virtual environment. Install Python 3.10+ first.
    pause
    exit /b 1
  )
  ".venv\Scripts\python.exe" -m pip -q install -r requirements.txt
  if errorlevel 1 (
    echo Dependency install failed.
    pause
    exit /b 1
  )
)

start "" http://127.0.0.1:8787
echo.
echo SFX Finder is running. Close this window to quit.
".venv\Scripts\python.exe" -m sfxfinder.server
pause
