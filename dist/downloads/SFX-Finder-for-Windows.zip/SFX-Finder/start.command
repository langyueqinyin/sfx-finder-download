#!/bin/bash
# 双击这个文件就能启动 SFX Finder。
cd "$(dirname "$0")" || exit 1

if [ ! -x .venv/bin/python ]; then
  echo "首次运行，正在装依赖…"
  python3 -m venv .venv || { echo "建 venv 失败，需要先装 Python 3"; read -r; exit 1; }
  .venv/bin/pip -q install -r requirements.txt || { echo "装依赖失败"; read -r; exit 1; }
fi

PORT=$(.venv/bin/python -c "import json;print(json.load(open('config.json')).get('port',8787))" 2>/dev/null || echo 8787)

service_ready() {
  curl -fsS -o /dev/null "http://127.0.0.1:$PORT/" && \
    curl -fsS -o /dev/null "http://127.0.0.1:$PORT/api/status"
}

# 已经在跑且网页入口正常就直接开浏览器，别起第二个。
if service_ready; then
  open "http://127.0.0.1:$PORT"
  exit 0
fi

# 旧版本可能只响应 API、却占着端口。让本次源码实例换一个端口启动。
if ! .venv/bin/python - "$PORT" <<'PY'
import socket
import sys

with socket.socket() as sock:
    try:
        sock.bind(("127.0.0.1", int(sys.argv[1])))
    except OSError:
        raise SystemExit(1)
PY
then
  PORT=$(.venv/bin/python - "$PORT" <<'PY'
import socket
import sys

start = int(sys.argv[1])
for port in range(start + 1, start + 21):
    with socket.socket() as sock:
        try:
            sock.bind(("127.0.0.1", port))
        except OSError:
            continue
        print(port)
        break
else:
    raise SystemExit("找不到可用端口")
PY
  )
fi

export SFX_PORT="$PORT"

.venv/bin/python -m sfxfinder.server &
SERVER_PID=$!
trap 'kill $SERVER_PID 2>/dev/null' EXIT

for _ in $(seq 1 40); do
  curl -s -o /dev/null "http://127.0.0.1:$PORT/api/status" && break
  sleep 0.25
done
open "http://127.0.0.1:$PORT"

echo
echo "SFX Finder 正在运行。关掉这个终端窗口就会退出。"
wait $SERVER_PID
