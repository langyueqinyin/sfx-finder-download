"""SQLite schema 与连接管理。"""
import os
import sqlite3

from . import config

SCHEMA = """

-- 路径拆成「基准路径 + 库内相对路径」：base_path 是盘/卷的挂载点
-- （macOS 的 /Volumes/T7 Shield、Windows 的 E:\），rel_root 是盘内到库根的路径。
-- 换盘只改 base_path 一个字段，几万条索引不用重建；同时这个拆法在 Windows 上也成立。
CREATE TABLE IF NOT EXISTS roots (
    id          INTEGER PRIMARY KEY,
    label       TEXT UNIQUE NOT NULL,
    volume_name TEXT NOT NULL,      -- 仅用于显示（卷名/盘符）
    rel_root    TEXT NOT NULL,
    probe_file  TEXT,               -- 用来确认这块盘确实是这个库
    enabled     INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS assets (
    id            INTEGER PRIMARY KEY,
    root_id       INTEGER NOT NULL REFERENCES roots(id),
    rel_path      TEXT NOT NULL,    -- 相对 rel_root，原样保存（不做 strip/规范化）
    filename      TEXT NOT NULL,
    stem          TEXT NOT NULL,
    ext           TEXT NOT NULL,
    folder_path   TEXT NOT NULL,    -- rel_path 的目录部分
    library       TEXT NOT NULL,    -- rel_path 的第一段，作为"库"分组
    code          TEXT,             -- 归一化后的编号，用来和对照表 join
    size          INTEGER,
    mtime         REAL,
    duration_ms   INTEGER,
    samplerate    INTEGER,
    channels      INTEGER,
    bitrate       INTEGER,
    probed_at     REAL,             -- NULL = 尚未探测
    duration_src  TEXT,             -- catalog | probe
    embedded_desc TEXT,
    catalog_desc  TEXT,
    category      TEXT,
    status        TEXT NOT NULL DEFAULT 'ok',
    content_key   TEXT,
    search_text   TEXT,             -- NFC + 小写，供 CJK/短词 LIKE 回退
    indexed_at    REAL,
    UNIQUE (root_id, rel_path)
);

CREATE INDEX IF NOT EXISTS idx_assets_code    ON assets(code);
CREATE INDEX IF NOT EXISTS idx_assets_status  ON assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_library ON assets(library);
CREATE INDEX IF NOT EXISTS idx_assets_probed  ON assets(probed_at);

CREATE VIRTUAL TABLE IF NOT EXISTS assets_fts USING fts5(
    descr, name, path,
    tokenize = 'unicode61 remove_diacritics 2'
);

CREATE TABLE IF NOT EXISTS catalog (
    code        TEXT PRIMARY KEY,
    description TEXT NOT NULL,
    duration_ms INTEGER,
    category    TEXT,
    source_file TEXT
);

CREATE TABLE IF NOT EXISTS term_stats (
    term TEXT PRIMARY KEY,
    df   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS cart (
    asset_id INTEGER PRIMARY KEY REFERENCES assets(id),
    added_at REAL NOT NULL,
    query    TEXT               -- 入篮时的搜索词，用于自动建目录
);

CREATE TABLE IF NOT EXISTS copy_log (
    id          INTEGER PRIMARY KEY,
    ts          REAL NOT NULL,
    dest_dir    TEXT NOT NULL,
    naming_mode TEXT NOT NULL,
    n_ok        INTEGER NOT NULL,
    n_skip      INTEGER NOT NULL,
    n_fail      INTEGER NOT NULL,
    detail_json TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


MIGRATIONS = [
    # 加基准路径。老库里只有 volume_name，按 macOS 的老规则补出来。
    ("roots", "base_path", "ALTER TABLE roots ADD COLUMN base_path TEXT",
     "UPDATE roots SET base_path = '/Volumes/' || volume_name WHERE base_path IS NULL"),
]

# 无关 schema 的数据修正，每次 connect 时按版本跑一次
DATA_FIXES = [
    # 早期版本把「根目录」这个中文写进了 library 字段，英文用户会在筛选器里看到它
    "UPDATE assets SET library = '' WHERE library = '(根目录)'",
]


SCHEMA_VERSION = 2


def connect(path=None):
    """建连接。

    建表只在库还没建好时做一次。以前是每个连接都 executescript(SCHEMA) 一遍——
    而 Flask 每个工作线程都会开自己的连接，前端又在每秒轮询进度，于是后台线程
    正在写 4 万行的时候，旁边不断有连接在跑 DDL 和 PRAGMA journal_mode。
    这会偶发地让扫描写入的数据丢掉（时好时坏，正是竞态的样子）。
    """
    path = path or config.DB_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 30000")
    if conn.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.executescript(SCHEMA)
        _migrate(conn)
        for fix in DATA_FIXES:
            conn.execute(fix)
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.commit()
    return conn


def _migrate(conn):
    for table, column, add_sql, backfill in MIGRATIONS:
        cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
        if column not in cols:
            conn.execute(add_sql)
            if backfill:
                conn.execute(backfill)
            conn.commit()


def sync_roots(conn, cfg=None):
    """把 config.json 里的 roots 同步进 db，以 label 为自然键。"""
    cfg = cfg or config.load()
    for r in cfg["roots"]:
        base = r.get("base") or os.path.join("/Volumes", r.get("volume", ""))
        conn.execute(
            """INSERT INTO roots (label, volume_name, base_path, rel_root, probe_file)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(label) DO UPDATE SET
                   volume_name = excluded.volume_name,
                   base_path   = excluded.base_path,
                   rel_root    = excluded.rel_root,
                   probe_file  = excluded.probe_file""",
            (r["label"], r.get("volume") or os.path.basename(base.rstrip("/\\")) or base,
             base, r["rel_root"], r.get("probe")),
        )
    conn.commit()
    return {row["label"]: row["id"] for row in conn.execute("SELECT id, label FROM roots")}


def root_abspath(row):
    """(root 行) -> 绝对路径。路径永远运行时拼装，从不入库。"""
    keys = row.keys()
    base = row["base_path"] if "base_path" in keys and row["base_path"] \
        else os.path.join("/Volumes", row["volume_name"])
    return os.path.join(base, row["rel_root"]) if row["rel_root"] else base


def asset_abspath(conn, asset_row):
    root = conn.execute("SELECT * FROM roots WHERE id = ?", (asset_row["root_id"],)).fetchone()
    return os.path.join(root_abspath(root), asset_row["rel_path"])


def get_setting(conn, key, default=None):
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key, value):
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, str(value)),
    )
    conn.commit()


def rebuild_fts(conn):
    """全量重建 FTS。4.7 万行几秒钟，比维护触发器简单可靠。"""
    conn.execute("DELETE FROM assets_fts")
    conn.execute(
        """INSERT INTO assets_fts (rowid, descr, name, path)
           SELECT id,
                  COALESCE(catalog_desc, '') || ' ' || COALESCE(embedded_desc, '')
                                             || ' ' || COALESCE(category, ''),
                  filename,
                  library || ' ' || folder_path
           FROM assets WHERE status = 'ok'"""
    )
    conn.commit()
