"""配置读写与路径。

要区分两种目录，因为打包成 .app 之后它们不在一起：
  RESOURCE_DIR  只读，随程序走（前端静态文件、近义词表）。打包后在 PyInstaller
                解压出的临时目录里。
  USER_DIR      可写，放配置和索引。打包后在用户目录下——.app 包内部不能写。
源码运行时两者都是项目目录，行为和以前一样。
"""
import json
import os
import sys

FROZEN = getattr(sys, "frozen", False)

# 调试/测试用：把配置和索引指到别处，不碰自己那份
_HOME_OVERRIDE = os.environ.get("SFX_FINDER_HOME")

if _HOME_OVERRIDE:
    RESOURCE_DIR = sys._MEIPASS if FROZEN else os.path.dirname(os.path.abspath(__file__))
    USER_DIR = os.path.abspath(os.path.expanduser(_HOME_OVERRIDE))
elif FROZEN:
    RESOURCE_DIR = sys._MEIPASS                      # PyInstaller 解压目录
    if sys.platform == "darwin":
        USER_DIR = os.path.expanduser("~/Library/Application Support/SFX Finder")
    elif sys.platform.startswith("win"):
        USER_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")),
                                "SFX Finder")
    else:
        USER_DIR = os.path.expanduser("~/.local/share/sfx-finder")
else:
    RESOURCE_DIR = os.path.dirname(os.path.abspath(__file__))
    USER_DIR = os.path.dirname(RESOURCE_DIR)

PKG_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(USER_DIR, "config.json")
DB_PATH = os.path.join(USER_DIR, "data", "sfx.db")
STATIC_DIR = os.path.join(RESOURCE_DIR, "sfxfinder", "static") if FROZEN \
    else os.path.join(PKG_DIR, "static")
DATA_DIR = os.path.join(RESOURCE_DIR, "sfxfinder", "data") if FROZEN \
    else os.path.join(PKG_DIR, "data")

if sys.platform == "darwin":
    CACHE_DIR = os.path.expanduser("~/Library/Caches/sfx-finder/preview")
elif sys.platform.startswith("win"):
    CACHE_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                             "SFX Finder", "preview")
else:
    CACHE_DIR = os.path.expanduser("~/.cache/sfx-finder/preview")

DEFAULTS = {
    "port": 8787,
    "roots": [],
    "audio_ext": [".wav", ".mp3", ".aif", ".aiff", ".flac", ".m4a", ".ogg", ".wma"],
    "catalog_ext": [".xls", ".xlsx", ".csv"],
    # 界面语言。lang_toggle=false 就不显示中英切换按钮——发给英文用户的版本用这个。
    "ui_lang": "auto",
    "lang_toggle": True,
}

# 遍历时直接跳过的文件/目录。exFAT 上 ._* 满地都是。
SKIP_NAMES = {".DS_Store", "Icon\r", "Icon", "__MACOSX", ".Spotlight-V100",
              ".fseventsd", ".TemporaryItems", "System Volume Information",
              "$RECYCLE.BIN", ".Trashes"}
SKIP_EXT = {".pek", ".cfa", ".avb", ".lck", ".log", ".plist", ".asd", ".sfk"}


def load():
    cfg = dict(DEFAULTS)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                cfg.update(json.load(f))
        except (OSError, ValueError):
            pass
    # The launcher can move to a free port when another SFX Finder build
    # left a stale service on the configured port.
    port_override = os.environ.get("SFX_PORT")
    if port_override:
        try:
            cfg["port"] = int(port_override)
        except ValueError:
            pass
    return cfg


def save(cfg):
    os.makedirs(USER_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
        f.write("\n")


def ensure_user_dir():
    """打包版第一次跑时，用户目录还不存在；顺便把默认配置落一份。

    打包时可以塞一份 bundled_config.json 进去当出厂设置——发给英文用户的版本
    就是靠它锁成英文单语的。用户之后改自己的 config.json 不会被覆盖。
    """
    os.makedirs(os.path.join(USER_DIR, "data"), exist_ok=True)
    if os.path.exists(CONFIG_PATH):
        return
    cfg = dict(DEFAULTS)
    bundled = os.path.join(RESOURCE_DIR, "bundled_config.json")
    if os.path.exists(bundled):
        try:
            with open(bundled, encoding="utf-8") as f:
                cfg.update(json.load(f))
        except (OSError, ValueError):
            pass
    save(cfg)
