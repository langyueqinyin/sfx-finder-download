"""Pass A：目录遍历。

只读目录项（文件名 / 大小 / mtime），**不打开任何文件**。macOS 批量读目录，
4.7 万条约 1-2 分钟，磁盘几乎无压力。时长这类要 open() 才能拿的东西一律
交给 probe.py 懒加载。
"""
import os
import time
import unicodedata

from . import config, db

# Sound Designer II 的拆分立体声，播不了，只进健康报告
SDII_EXT = {".l", ".r"}


def norm_code(stem):
    """编号归一化：大写、去首尾空格、分隔符统一成 _。"""
    return stem.strip().upper().replace("-", "_")


def norm_text(s):
    """搜索用文本：NFC 归一 + 小写。macOS 上中文文件名可能是 NFD。"""
    return unicodedata.normalize("NFC", s or "").lower()


def _walk(abs_root, audio_ext):
    """产出 (rel_path, size, mtime, kind)。kind: audio | sdii"""
    stack = [""]
    while stack:
        rel_dir = stack.pop()
        try:
            it = os.scandir(os.path.join(abs_root, rel_dir) if rel_dir else abs_root)
        except OSError:
            continue
        with it:
            for entry in it:
                name = entry.name
                if name.startswith("._") or name in config.SKIP_NAMES:
                    continue
                rel = f"{rel_dir}/{name}" if rel_dir else name
                try:
                    if entry.is_dir(follow_symlinks=False):
                        stack.append(rel)
                        continue
                    ext = os.path.splitext(name)[1].lower()
                    if ext in config.SKIP_EXT:
                        continue
                    if ext in audio_ext:
                        kind = "audio"
                    elif ext in SDII_EXT:
                        kind = "sdii"
                    else:
                        continue
                    st = entry.stat(follow_symlinks=False)
                    yield rel, st.st_size, st.st_mtime, kind
                except OSError:
                    continue


def scan_root(conn, root_row, audio_ext, progress=None):
    abs_root = db.root_abspath(root_row)
    if not os.path.isdir(abs_root):
        raise FileNotFoundError(f"库路径不存在（盘没挂载？）: {abs_root}")

    root_id = root_row["id"]
    existing = {
        r["rel_path"]: (r["id"], r["size"], r["mtime"], r["status"])
        for r in conn.execute(
            "SELECT id, rel_path, size, mtime, status FROM assets WHERE root_id = ?", (root_id,)
        )
    }
    seen = set()
    now = time.time()
    n_new = n_upd = n_same = 0

    for rel, size, mtime, kind in _walk(abs_root, audio_ext):
        seen.add(rel)
        prev = existing.get(rel)
        if prev and prev[1] == size and prev[2] == mtime:
            n_same += 1
            if prev[3] == "missing":  # 消失过又回来了（多半是盘没挂载那次扫的）
                conn.execute("UPDATE assets SET status='ok' WHERE id=?", (prev[0],))
            if progress and (n_new + n_upd + n_same) % 10000 == 0:
                progress(n_new + n_upd + n_same)
            continue

        filename = os.path.basename(rel)
        stem, ext = os.path.splitext(filename)
        folder_path = os.path.dirname(rel)
        # 直接躺在库根下的文件用空串表示；显示成什么字由前端按语言决定
        library = rel.split("/", 1)[0] if "/" in rel else ""
        if kind == "sdii":
            status = "unsupported"
        elif size == 0:
            status = "zero_byte"
        else:
            status = "ok"

        row = (
            root_id, rel, filename, stem, ext.lower(), folder_path, library,
            norm_code(stem), size, mtime, status,
            f"{norm_text(stem)}|{size}",
            norm_text(f"{filename} {folder_path} {library}"),
            now,
        )
        if prev:
            conn.execute(
                """UPDATE assets SET filename=?, stem=?, ext=?, folder_path=?, library=?,
                       code=?, size=?, mtime=?, status=?, content_key=?, search_text=?,
                       indexed_at=?, probed_at=NULL, duration_ms=NULL, duration_src=NULL
                   WHERE id=?""",
                row[2:] + (prev[0],),
            )
            n_upd += 1
        else:
            conn.execute(
                """INSERT INTO assets (root_id, rel_path, filename, stem, ext, folder_path,
                       library, code, size, mtime, status, content_key, search_text, indexed_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                row,
            )
            n_new += 1
        if progress and (n_new + n_upd + n_same) % 10000 == 0:
            progress(n_new + n_upd + n_same)

    gone = [rel for rel in existing if rel not in seen]
    for rel in gone:
        conn.execute(
            "UPDATE assets SET status='missing' WHERE root_id=? AND rel_path=?", (root_id, rel)
        )
    conn.commit()
    return {"new": n_new, "updated": n_upd, "unchanged": n_same, "gone": len(gone),
            "total_seen": len(seen)}


def scan_all(conn, verbose=True):
    cfg = config.load()
    db.sync_roots(conn, cfg)
    audio_ext = set(cfg["audio_ext"])
    results = {}
    for root_row in conn.execute("SELECT * FROM roots WHERE enabled = 1"):
        label = root_row["label"]
        if verbose:
            print(f"[scan] {label} -> {db.root_abspath(root_row)}")
        cb = (lambda n, lb=label: print(f"  {lb}: {n} …", flush=True)) if verbose else None
        try:
            results[label] = scan_root(conn, root_row, audio_ext, progress=cb)
        except FileNotFoundError as e:
            print(f"  跳过：{e}")
            results[label] = {"error": str(e)}
        if verbose and "error" not in results[label]:
            r = results[label]
            print(f"  新增 {r['new']} / 更新 {r['updated']} / 未变 {r['unchanged']} / 消失 {r['gone']}")
    return results
