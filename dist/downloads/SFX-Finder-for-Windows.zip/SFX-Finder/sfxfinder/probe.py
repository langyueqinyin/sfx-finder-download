"""懒探测：只在需要时打开单个文件读文件头。

**不做全库扫描。** 4.7 万次随机 IO 在 USB 外置盘上要几十分钟，还会拖慢用户
手头别的活；而搜索压根不依赖时长。所以只探测「当前屏幕上这几十条」，
探完写回库，下次免费。想要全库补全的话有单独的限速后台任务。
"""
import os
import struct
import subprocess
import time

HEADER_BYTES = 256 * 1024


# ------------------------------------------------- 嵌入描述（RIFF / AIFF）

def _riff_desc(head):
    """WAV：LIST-INFO 里的 INAM/ICMT/ISBJ，以及 bext 的描述字段。"""
    out = []
    pos = 12
    while pos + 8 <= len(head):
        cid = head[pos:pos + 4]
        try:
            size = struct.unpack("<I", head[pos + 4:pos + 8])[0]
        except struct.error:
            break
        body = head[pos + 8:pos + 8 + size]
        if cid == b"LIST" and body[:4] == b"INFO":
            p = 4
            while p + 8 <= len(body):
                sid = body[p:p + 4]
                ssize = struct.unpack("<I", body[p + 4:p + 8])[0]
                if sid in (b"INAM", b"ICMT", b"ISBJ", b"IKEY"):
                    out.append(body[p + 8:p + 8 + ssize].split(b"\x00")[0]
                               .decode("utf-8", "replace"))
                p += 8 + ssize + (ssize & 1)
        elif cid == b"bext":
            out.append(body[:256].split(b"\x00")[0].decode("utf-8", "replace"))
        pos += 8 + size + (size & 1)
    return " ".join(s.strip() for s in out if s.strip())


def _aiff_desc(head):
    out = []
    pos = 12
    while pos + 8 <= len(head):
        cid = head[pos:pos + 4]
        try:
            size = struct.unpack(">I", head[pos + 4:pos + 8])[0]
        except struct.error:
            break
        if cid in (b"NAME", b"ANNO", b"AUTH"):
            out.append(head[pos + 8:pos + 8 + size].split(b"\x00")[0]
                       .decode("utf-8", "replace"))
        pos += 8 + size + (size & 1)
    return " ".join(s.strip() for s in out if s.strip())


def embedded_description(path):
    try:
        with open(path, "rb") as f:
            head = f.read(HEADER_BYTES)
    except OSError:
        return ""
    if head[:4] == b"RIFF":
        return _riff_desc(head)
    if head[:4] == b"FORM" and head[8:12] in (b"AIFF", b"AIFC"):
        return _aiff_desc(head)
    return ""


# ------------------------------------------------- 时长 / 格式

def _ffprobe(path):
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "quiet", "-select_streams", "a:0", "-show_entries",
             "stream=duration,sample_rate,channels,bit_rate", "-of", "default=nw=1", path],
            capture_output=True, text=True, timeout=20,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return {}
    d = {}
    for line in out.splitlines():
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        if v in ("N/A", ""):
            continue
        try:
            d[k] = float(v)
        except ValueError:
            pass
    return d


def probe_one(path):
    """返回 dict。任何一步失败都降级，不抛异常。"""
    info = {"duration_ms": None, "samplerate": None, "channels": None,
            "bitrate": None, "embedded_desc": None}
    try:
        import mutagen
        mf = mutagen.File(path)
        if mf is not None and mf.info is not None:
            i = mf.info
            if getattr(i, "length", None):
                info["duration_ms"] = int(i.length * 1000)
            info["samplerate"] = getattr(i, "sample_rate", None)
            info["channels"] = getattr(i, "channels", None)
            info["bitrate"] = getattr(i, "bitrate", None)
    except Exception:
        pass

    if not info["duration_ms"]:
        d = _ffprobe(path)
        if d.get("duration"):
            info["duration_ms"] = int(d["duration"] * 1000)
        info["samplerate"] = info["samplerate"] or int(d.get("sample_rate") or 0) or None
        info["channels"] = info["channels"] or int(d.get("channels") or 0) or None
        info["bitrate"] = info["bitrate"] or int(d.get("bit_rate") or 0) or None

    desc = embedded_description(path)
    info["embedded_desc"] = desc or None
    return info


def probe_ids(conn, ids, force=False):
    """探测一批 asset id 并写回库。返回 {id: info}。"""
    if not ids:
        return {}
    from . import db
    qs = ",".join("?" * len(ids))
    cond = "" if force else " AND probed_at IS NULL"
    rows = conn.execute(
        f"SELECT * FROM assets WHERE id IN ({qs}){cond}", list(ids)
    ).fetchall()
    now = time.time()
    out = {}
    for row in rows:
        path = db.asset_abspath(conn, row)
        if not os.path.exists(path):
            conn.execute("UPDATE assets SET status='missing', probed_at=? WHERE id=?",
                         (now, row["id"]))
            continue
        info = probe_one(path)
        # 对照表给的时长更可信也更省事，别用探测结果覆盖它
        keep_dur = row["duration_src"] == "catalog" and row["duration_ms"]
        conn.execute(
            """UPDATE assets SET
                   duration_ms   = CASE WHEN ? THEN duration_ms ELSE COALESCE(?, duration_ms) END,
                   duration_src  = CASE WHEN ? THEN duration_src ELSE 'probe' END,
                   samplerate    = COALESCE(?, samplerate),
                   channels      = COALESCE(?, channels),
                   bitrate       = COALESCE(?, bitrate),
                   embedded_desc = COALESCE(?, embedded_desc),
                   probed_at     = ?
               WHERE id = ?""",
            (keep_dur, info["duration_ms"], keep_dur, info["samplerate"], info["channels"],
             info["bitrate"], info["embedded_desc"], now, row["id"]),
        )
        out[row["id"]] = info
    conn.commit()
    return out
