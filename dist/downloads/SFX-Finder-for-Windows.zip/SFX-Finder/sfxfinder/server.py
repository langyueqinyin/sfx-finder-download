"""Flask 服务端。只监听 127.0.0.1，单用户本地工具。"""
import json
import os
import subprocess
import threading
import time

from flask import Flask, Response, jsonify, request, send_file, send_from_directory

from . import config, copier, db, health, onboard, probe, scanner, search, suggest, volumes

STATIC = config.STATIC_DIR
# 浏览器能直接放的格式，其余转 mp3 预览
NATIVE_EXT = {".mp3", ".wav", ".flac", ".m4a", ".ogg"}

app = Flask(__name__, static_folder=None)
_local = threading.local()

# 后台任务（重扫 / 全库补时长）的状态
job = {"kind": None, "running": False, "done": 0, "total": 0, "msg": "", "stop": False}
_job_lock = threading.Lock()


def conn():
    if getattr(_local, "conn", None) is None:
        _local.conn = db.connect()
    return _local.conn


# ------------------------------------------------------------------ 页面

@app.route("/")
def index():
    return send_from_directory(STATIC, "index.html")


@app.route("/static/ui-config.js")
def ui_config():
    """把 config.json 里的界面设置塞给前端，在 i18n.js 之前加载。"""
    cfg = config.load()
    body = "window.UI_CONFIG = %s;\n" % json.dumps({
        "lang": cfg.get("ui_lang", "auto"),
        "lang_toggle": cfg.get("lang_toggle", True),
    })
    return Response(body, mimetype="application/javascript")


@app.route("/static/<path:name>")
def static_files(name):
    return send_from_directory(STATIC, name)


# ------------------------------------------------------------------ 搜索

@app.route("/api/search")
def api_search():
    a = request.args
    limit = a.get("limit", 100, type=int)
    group = a.get("group", "1") == "1"
    kw = dict(
        library=a.get("library") or None,
        ext=a.get("ext") or None,
        dur_min=a.get("dur_min", type=int),
        dur_max=a.get("dur_max", type=int),
        has_desc=a.get("has_desc") == "1",
        sort=a.get("sort", "relevance"),
        offset=a.get("offset", 0, type=int),
    )
    # 折叠时多捞几倍，折完才够一屏
    fetch = limit * 5 if group else limit
    if a.get("loose", "1") == "1":
        # 精确搜不到就逐级放宽（body hit ground -> bodyfall on dirt）
        rows, total, relax = search.search_loose(conn(), a.get("q", ""), limit=fetch, **kw)
    else:
        rows, total = search.search(conn(), a.get("q", ""), limit=fetch, **kw)
        relax = None
    consumed = len(rows)
    if group:
        rows, consumed = search.collapse_dupes(rows, limit)
    # consumed 是原始行数，「加载更多」要按它推进 offset，不能按组数
    return jsonify({"rows": rows, "total": total, "grouped": group,
                    "consumed": consumed, "relax": relax})


@app.route("/api/suggest")
def api_suggest():
    """独立接口：推荐词算得比搜索慢，前端异步拉，不挡着结果先显示。"""
    return jsonify(suggest.related_terms(
        conn(), request.args.get("q", ""), library=request.args.get("library") or None))


@app.route("/api/facets")
def api_facets():
    return jsonify({"libraries": search.facets(conn())})


@app.route("/api/probe", methods=["POST"])
def api_probe():
    ids = request.json.get("ids", [])[:200]
    probe.probe_ids(conn(), ids)
    qs = ",".join("?" * len(ids)) if ids else "NULL"
    rows = conn().execute(
        f"SELECT id, duration_ms, samplerate, channels, duration_src, embedded_desc, status "
        f"FROM assets WHERE id IN ({qs})", ids).fetchall() if ids else []
    return jsonify({"rows": [dict(r) for r in rows]})


# ------------------------------------------------------------------ 播放

def _preview_path(row):
    """非原生格式转成 mp3 缓存一份。同一条只转一次。"""
    os.makedirs(config.CACHE_DIR, exist_ok=True)
    out = os.path.join(config.CACHE_DIR, f"{row['id']}.mp3")
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    src = db.asset_abspath(conn(), row)
    try:
        subprocess.run(
            ["ffmpeg", "-v", "quiet", "-y", "-i", src, "-vn",
             "-c:a", "libmp3lame", "-b:a", "128k", out],
            check=True, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    return out if os.path.exists(out) else None


@app.route("/api/audio/<int:aid>")
def api_audio(aid):
    row = conn().execute("SELECT * FROM assets WHERE id=?", (aid,)).fetchone()
    if row is None:
        return jsonify({"err": "not_found"}), 404
    src = db.asset_abspath(conn(), row)
    if not os.path.exists(src):
        return jsonify({"err": "src_missing"}), 410
    if row["ext"] in NATIVE_EXT:
        # conditional=True 打开 Range 支持，播放器才能拖动定位
        return send_file(src, conditional=True)
    out = _preview_path(row)
    if out is None:
        return jsonify({"err": "transcode_failed"}), 500
    return send_file(out, mimetype="audio/mpeg", conditional=True)


# ------------------------------------------------------------------ 购物车

@app.route("/api/cart", methods=["GET"])
def api_cart_get():
    rows = conn().execute("""
        SELECT a.id, a.filename, a.ext, a.library, a.folder_path, a.duration_ms,
               a.catalog_desc, a.embedded_desc, c.query, c.added_at
        FROM cart c JOIN assets a ON a.id = c.asset_id ORDER BY c.added_at""").fetchall()
    rows = [dict(r) for r in rows]
    return jsonify({
        "rows": rows,
        "suggested_folder": copier.folder_from_query(_dominant_query(rows)),
        "recent_dests": copier.recent_destinations(conn()),
        "naming_mode": db.get_setting(conn(), "naming_mode", "orig"),
        "last_dest": db.get_setting(conn(), "last_dest", ""),
        **_description_summary(rows),
    })


def _description_summary(rows):
    described = sum(bool((r.get("catalog_desc") or r.get("embedded_desc") or "").strip())
                    for r in rows)
    return {"described_count": described, "total_count": len(rows)}


def _dominant_query(rows):
    """篮子里混了好几次搜索的结果时，用占比最高的那个词当目录名。"""
    counts = {}
    for r in rows:
        if r.get("query"):
            counts[r["query"]] = counts.get(r["query"], 0) + 1
    return max(counts, key=counts.get) if counts else ""


@app.route("/api/cart", methods=["POST"])
def api_cart_add():
    body = request.json or {}
    ids = body.get("ids", [])
    q = body.get("query", "")
    now = time.time()
    for i, aid in enumerate(ids):
        conn().execute(
            "INSERT INTO cart (asset_id, added_at, query) VALUES (?,?,?) "
            "ON CONFLICT(asset_id) DO NOTHING", (aid, now + i * 1e-6, q))
    conn().commit()
    return jsonify({"n": conn().execute("SELECT count(*) n FROM cart").fetchone()["n"]})


@app.route("/api/cart", methods=["DELETE"])
def api_cart_del():
    body = request.json or {}
    if body.get("all"):
        conn().execute("DELETE FROM cart")
    else:
        ids = body.get("ids", [])
        qs = ",".join("?" * len(ids))
        conn().execute(f"DELETE FROM cart WHERE asset_id IN ({qs})", ids)
    conn().commit()
    return jsonify({"n": conn().execute("SELECT count(*) n FROM cart").fetchone()["n"]})


# ------------------------------------------------------------------ 拷贝

@app.route("/api/copy", methods=["POST"])
def api_copy():
    b = request.json or {}
    dest_root = (b.get("dest_root") or "").strip()
    if not dest_root:
        return jsonify({"err": "no_dest"}), 400
    if not os.path.isdir(os.path.expanduser(dest_root)):
        return jsonify({"err": "dest_missing", "args": [dest_root]}), 400

    ids = b.get("ids")
    if not ids:
        ids = [r["asset_id"] for r in conn().execute(
            "SELECT asset_id FROM cart ORDER BY added_at")]
    if not ids:
        return jsonify({"err": "cart_empty"}), 400

    naming = b.get("naming_mode", "desc_orig")
    db.set_setting(conn(), "naming_mode", naming)
    db.set_setting(conn(), "last_dest", dest_root)
    rep = copier.copy_assets(
        conn(), ids, dest_root,
        subfolder=b.get("subfolder", ""),
        naming_mode=naming,
        preserve_tree=bool(b.get("preserve_tree")),
        on_conflict=b.get("on_conflict", "suffix"),
    )
    if b.get("clear_cart"):
        conn().execute("DELETE FROM cart")
        conn().commit()
    return jsonify(rep)


@app.route("/api/choose-folder", methods=["POST"])
def api_choose_folder():
    prompt = (request.json or {}).get("prompt") or "选择文件夹"
    return jsonify({"path": volumes.choose_folder(prompt),
                    "native": volumes.IS_MAC or volumes.IS_WIN})


# ------------------------------------------------------------------ 首次引导

@app.route("/api/setup/state")
def api_setup_state():
    return jsonify({
        "needs_setup": onboard.needs_setup(conn()),
        "native_picker": volumes.IS_MAC or volumes.IS_WIN,
        "volumes": volumes.list_volumes(),
        "roots": volumes.root_status(conn()),
    })


@app.route("/api/setup/inspect", methods=["POST"])
def api_setup_inspect():
    path = (request.json or {}).get("path", "")
    if not path.strip():
        return jsonify({"err": "no_path"}), 400
    return jsonify(onboard.inspect(path))


@app.route("/api/setup/apply", methods=["POST"])
def api_setup_apply():
    b = request.json or {}
    path = (b.get("path") or "").strip()
    if not path:
        return jsonify({"err": "no_path"}), 400
    info = onboard.inspect(path)
    if not info["ok"]:
        return jsonify({"err": info["err"] or "no_audio"}), 400

    # 重设库要先清空 assets。这一步必须和扫描放在同一个受 job 锁保护的任务里——
    # 之前是在这里直接清，然后才去抢锁，于是重复提交的第二个 apply 会把上一个
    # 刚扫完的 4 万条删掉，界面上就成了「建完索引一条也搜不到」。
    def work(c):
        onboard.apply(c, path, label=b.get("label"))
        job["msg"] = "walking"
        job["detail"] = _index_pipeline(c)
        job["msg"] = "done"

    if not _run_job("setup", work):
        return jsonify({"err": "busy"}), 409
    return jsonify({"started": True})


@app.route("/api/reveal", methods=["POST"])
def api_reveal():
    b = request.json or {}
    if b.get("id"):
        row = conn().execute("SELECT * FROM assets WHERE id=?", (b["id"],)).fetchone()
        return jsonify({"ok": row is not None and volumes.reveal(db.asset_abspath(conn(), row))})
    return jsonify({"ok": volumes.open_dir(os.path.expanduser(b.get("path", "")))})


# ------------------------------------------------------------------ 卷 / 索引 / 健康

@app.route("/api/status")
def api_status():
    c = conn()
    return jsonify({
        "roots": volumes.root_status(c),
        "volumes": volumes.list_volumes(),
        "cart_n": c.execute("SELECT count(*) n FROM cart").fetchone()["n"],
        "unprobed": c.execute(
            "SELECT count(*) n FROM assets WHERE status='ok' AND probed_at IS NULL"
        ).fetchone()["n"],
        "job": dict(job),
    })


@app.route("/api/roots/<int:rid>/candidates")
def api_candidates(rid):
    return jsonify({"candidates": volumes.find_candidates(conn(), rid)})


@app.route("/api/roots/<int:rid>/repoint", methods=["POST"])
def api_repoint(rid):
    base = (request.json or {}).get("base_path")
    if not base:
        return jsonify({"err": "no_volume"}), 400
    return jsonify({"roots": volumes.repoint(conn(), rid, base)})


@app.route("/api/health")
def api_health():
    return jsonify(health.report(conn(), deep=request.args.get("deep") != "0"))


def _index_pipeline(c):
    """遍历 -> 读对照表 -> 建词表。

    返回的东西会进 job 状态：打包版没有终端，用户报「建完索引搜不到东西」时，
    这几个数字是唯一能判断卡在哪一步的依据。
    """
    from . import catalog
    scanned = scanner.scan_all(c, verbose=False)
    job["msg"] = "catalog"
    catalog.import_catalogs(c, verbose=False)
    job["msg"] = "terms"
    n_terms = suggest.build_term_stats(c, verbose=False)
    n_ok = c.execute("SELECT count(*) FROM assets WHERE status='ok'").fetchone()[0]
    return {"scanned": scanned, "terms": n_terms, "assets_ok": n_ok}


def _run_job(kind, fn):
    with _job_lock:
        if job["running"]:
            return False
        job.update(kind=kind, running=True, done=0, total=0, msg="", stop=False)
    threading.Thread(target=_job_wrapper, args=(fn,), daemon=True).start()
    return True


def _job_wrapper(fn):
    c = db.connect()
    try:
        fn(c)
    except Exception as e:          # 后台任务不该把服务搞挂
        job["msg"] = "error"
        job["error"] = str(e)
        # 打包版没有终端，栈只能写文件，否则出问题时无据可查
        try:
            import traceback
            os.makedirs(config.USER_DIR, exist_ok=True)
            with open(os.path.join(config.USER_DIR, "job-errors.log"), "a",
                      encoding="utf-8") as f:
                f.write(traceback.format_exc() + "\n")
        except OSError:
            pass
    finally:
        job["running"] = False
        c.close()


@app.route("/api/index/rescan", methods=["POST"])
def api_rescan():
    def work(c):
        job["msg"] = "walking"
        job["detail"] = _index_pipeline(c)
        job["msg"] = "done"
    return jsonify({"started": _run_job("rescan", work)})


@app.route("/api/index/fill-metadata", methods=["POST"])
def api_fill():
    """全库补时长。默认不跑——限速在这儿是为了不抢用户手头别的活的磁盘。"""
    rate = (request.json or {}).get("rate", 50)

    def work(c):
        ids = [r["id"] for r in c.execute(
            "SELECT id FROM assets WHERE status='ok' AND probed_at IS NULL")]
        job["total"] = len(ids)
        for i in range(0, len(ids), 20):
            if job["stop"]:
                job["msg"] = "paused"
                return
            t0 = time.time()
            probe.probe_ids(c, ids[i:i + 20])
            job["done"] = min(i + 20, len(ids))
            job["msg"] = f"{job['done']}/{job['total']}"
            sleep = 20 / max(rate, 1) - (time.time() - t0)
            if sleep > 0:
                time.sleep(sleep)
        job["msg"] = "done"
    return jsonify({"started": _run_job("fill", work)})


@app.route("/api/index/stop", methods=["POST"])
def api_stop():
    job["stop"] = True
    return jsonify({"ok": True})


def main(open_browser=None):
    config.ensure_user_dir()
    cfg = config.load()
    c = db.connect()
    db.sync_roots(c, cfg)
    n = c.execute("SELECT count(*) n FROM assets WHERE status='ok'").fetchone()["n"]
    port = cfg.get("port", 8787)
    url = f"http://127.0.0.1:{port}"

    print(f"SFX Finder — {n} clips indexed")
    print(f"Open {url}")
    if config.FROZEN:
        print(f"Settings and index live in: {config.USER_DIR}")

    # 打包成 app 之后没有启动脚本帮忙开浏览器了，自己开
    if open_browser is None:
        open_browser = config.FROZEN
    if os.environ.get("SFX_NO_BROWSER"):        # 压测时别每轮弹一个窗口
        open_browser = False
    if open_browser:
        import threading as _t
        import webbrowser
        _t.Timer(1.2, lambda: webbrowser.open(url)).start()

    app.run(host="127.0.0.1", port=port, threaded=True, debug=False)


if __name__ == "__main__":
    main()
