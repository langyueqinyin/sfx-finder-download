"""模糊匹配：把「你会打的词」翻译成「库里实际写的词」。

问题很具体：搜 `body hit ground` 在这块盘上是 0 条，但库里躺着 48 条
`BODYFALL, HUMAN — BODYFALL ON DIRT`；搜 `high heel concrete` 是 0 条，
而 `HIGH HEELS ON GRITTY CEMENT` 有 67 条。两个病因——三个词必须全中，
以及词汇不对齐（你说 hit ground，库里写 fall on dirt；你说 concrete，
Sound Ideas 写 cement）。

做法不需要嵌入模型（音效描述的词汇是收敛的）：

1. 把查询拆成**概念**，每个概念 = 一个词 + 它在这个库里真实存在的近义词
   （扩展词先查 term_stats，库里没有的直接丢掉——所以换成别人的库也不会引入噪音）
2. **概念内 OR，概念间 AND**：("body" OR "bodyfall") AND ("hit" OR "fall" OR "thud")
   AND ("ground" OR "dirt" OR "concrete")
3. 还是不够，就**丢掉最没信息量的那个概念**（df 最高的那个，比如 "hit"），再试一次

精确匹配永远优先，放宽是有序的，而且会把「实际用了什么词」回给界面，
不让用户以为这就是精确结果。
"""
import json
import os
import re
from collections import defaultdict

from . import config

WORD = re.compile(r"[a-z]{2,}")
SYN_PATH = os.path.join(config.DATA_DIR, "sfx_synonyms.json")

# 这些词单独拿出来查毫无意义，只会把结果冲淡
NOISE = {"the", "a", "an", "and", "or", "of", "on", "in", "at", "to", "with",
         "for", "from", "into", "sound", "sfx", "effect", "audio", "fx"}

_syn_index = None


def synonym_index():
    """做一层对称闭包（a→b 则 b→a），但不做传递闭包——
    hit→impact→boom→explosion 那样传下去就跑偏了。"""
    global _syn_index
    if _syn_index is None:
        with open(SYN_PATH, encoding="utf-8") as f:
            raw = json.load(f)
        idx = defaultdict(set)
        for k, vs in raw.items():
            if k.startswith("_"):
                continue
            for v in vs:
                idx[k].add(v)
                idx[v].add(k)
        _syn_index = {k: sorted(v) for k, v in idx.items()}
    return _syn_index


def _df_map(conn, words):
    if not words:
        return {}
    qs = ",".join("?" * len(words))
    return {r["term"]: r["df"] for r in conn.execute(
        f"SELECT term, df FROM term_stats WHERE term IN ({qs})", list(words))}


# 扩展是为了找「库里的另一种说法」，不是为了泛化成更宽的概念。判据是**相对量级**，
# 不是绝对频次：
#   car(1051) ↔ auto(1921)   同一量级，是真等价词——Sound Ideas 里车全写 AUTO，
#                            这个词砍掉就搜不到 "AUTO, FORD ESCORT — DOOR SLAM CLOSE"
#   body(341) → human(1669)  宽了一个层级，是上位词，留着会把狗和打篮球的人带进来
# 词形变体（heel/heels、slam/slams、close/closed）走另一条免检通道，不受此限。
SYN_DF_MULTIPLE = 4
SYN_DF_FLOOR = 300


def same_root(a, b):
    """够用的同源判断：单复数、-s / -ed / -ing 这类词形变体。"""
    x, y = sorted((a, b), key=len)
    return y.startswith(x) and 0 < len(y) - len(x) <= 3


def build_concepts(conn, q, max_syn=8):
    """查询 -> [{'orig': 'ground', 'terms': ['ground','dirt','concrete',...], ...}]

    扩展词只保留库里真的有、且不比原词泛太多的。
    """
    words = [w for w in WORD.findall(q.lower()) if w not in NOISE]
    if not words:
        return []
    syn = synonym_index()

    wanted = set(words)
    for w in words:
        wanted |= set(syn.get(w, []))
    df = _df_map(conn, wanted)

    concepts = []
    for w in words:
        cap = max(df.get(w, 0) * SYN_DF_MULTIPLE, SYN_DF_FLOOR)
        keep = [s for s in syn.get(w, [])
                if s != w and df.get(s, 0) > 0
                and (same_root(w, s) or df[s] <= cap)]
        # 原词永远排第一，扩展词按库里越少见越靠前（更有区分度）
        rest = sorted(keep, key=lambda c: df.get(c, 0))
        terms = ([w] if df.get(w, 0) > 0 else []) + rest[:max_syn]
        if not terms:
            continue
        concepts.append({
            "orig": w,
            "terms": terms,
            # 信息量看**原词自己**的频次，不能看扩展词。
            # body 在库里只有 341 条（0.72%）很有区分度，但它的扩展词 human/person
            # 是高频词——按扩展词判断会把 body 当成泛词丢掉，结果搜 body hit ground
            # 出来一堆篮球拍地。hit 才是那个该丢的（1395 条，2.95%）。
            "orig_df": df.get(w, 0),
        })
    return concepts


def fts_expr(concepts):
    """概念内 OR，概念间 AND。"""
    parts = []
    for c in concepts:
        inner = " OR ".join(f'"{t}"' for t in c["terms"])
        parts.append(f"({inner})" if len(c["terms"]) > 1 else inner)
    return " AND ".join(parts)


def relaxation_plan(concepts):
    """产出一串由严到松的方案。每次丢掉**原词**最常见的那个概念
    （库里到处都是 = 信息量最低），把有区分度的词留到最后。"""
    plans = [list(concepts)]
    cur = list(concepts)
    while len(cur) > 1:
        weakest = max(range(len(cur)), key=lambda i: cur[i]["orig_df"])
        cur = cur[:weakest] + cur[weakest + 1:]
        plans.append(list(cur))
    return plans


def describe(concepts, original_words):
    """回给界面：每个原词最后是用哪些词去搜的，哪些词被丢了。"""
    used = {c["orig"]: c["terms"] for c in concepts}
    return {
        "used": [{"orig": c["orig"], "terms": c["terms"][:6]} for c in concepts],
        "dropped": [w for w in original_words if w not in used],
    }
