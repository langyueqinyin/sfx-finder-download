"""首次引导：检查用户选择的任意音效总文件夹，再建立本地索引。

目录表是可选增强；没有目录表时，文件名、目录名和音频内嵌描述仍可搜索。
"""
import os
import time

from . import config, db

# 预检不做全量遍历——4 万个文件要十几秒，引导页等不起。
# 数到这个量或超时就停，报个「至少 N 个」够用来确认「选对了没有」。
PREVIEW_CAP = 6000
PREVIEW_SECONDS = 6.0


def inspect(path, audio_ext=None, catalog_ext=None):
    """看一眼这个文件夹，返回够不够格当素材库。"""
    cfg = config.load()
    audio_ext = set(audio_ext or cfg["audio_ext"])
    catalog_ext = set(catalog_ext or cfg["catalog_ext"])

    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.isdir(path):
        return {"ok": False, "err": "dir_missing", "path": path}

    t0 = time.time()
    n_audio = 0
    catalogs = []
    samples = []
    top_dirs = []
    truncated = False
    stack = [""]

    while stack:
        rel_dir = stack.pop()
        try:
            it = os.scandir(os.path.join(path, rel_dir) if rel_dir else path)
        except OSError:
            continue
        with it:
            for e in it:
                if e.name.startswith("._") or e.name in config.SKIP_NAMES:
                    continue
                rel = f"{rel_dir}/{e.name}" if rel_dir else e.name
                try:
                    if e.is_dir(follow_symlinks=False):
                        if not rel_dir:
                            top_dirs.append(e.name)
                        stack.append(rel)
                        continue
                except OSError:
                    continue
                ext = os.path.splitext(e.name)[1].lower()
                if ext in audio_ext:
                    n_audio += 1
                    if len(samples) < 6:
                        samples.append(rel)
                elif ext in catalog_ext:
                    try:
                        size = e.stat().st_size
                    except OSError:
                        size = 0
                    catalogs.append({"rel": rel, "size": size})
        if n_audio >= PREVIEW_CAP or time.time() - t0 > PREVIEW_SECONDS:
            truncated = True
            break

    base, rel_root = _split(path)
    return {
        "ok": n_audio > 0,
        "err": None if n_audio > 0 else "no_audio",
        "path": path,
        "base_path": base,
        "rel_root": rel_root,
        "n_audio": n_audio,
        "truncated": truncated,           # 真实数量比这个多，建库时才数得准
        "catalogs": sorted(catalogs, key=lambda c: -c["size"])[:8],
        "samples": samples,
        "top_dirs": sorted(top_dirs)[:14],
        "elapsed": round(time.time() - t0, 1),
    }


def _split(path):
    from . import volumes
    return volumes.split_base(path)


def apply(conn, path, label=None, probe=None, replace=True):
    """把选中的文件夹写成 config.json 里的 root。"""
    from . import volumes

    path = os.path.abspath(os.path.expanduser(path))
    base, rel_root = volumes.split_base(path)
    label = label or os.path.basename(path.rstrip("/\\")) or "SFX"

    # 挑一个稳定存在的文件当标志，用来确认「这块盘确实是这个库」
    if probe is None:
        info = inspect(path)
        cat = info["catalogs"][0]["rel"] if info["catalogs"] else None
        probe = cat or (info["samples"][0] if info["samples"] else None)

    cfg = config.load()
    entry = {"label": label, "volume": volumes.volume_label(base),
             "base": base, "rel_root": rel_root, "probe": probe}
    if replace:
        cfg["roots"] = [entry]
    else:
        cfg["roots"] = [r for r in cfg["roots"] if r["label"] != label] + [entry]
    config.save(cfg)

    if replace:
        conn.execute("DELETE FROM assets")
        conn.execute("DELETE FROM roots")
        conn.execute("DELETE FROM catalog")
        conn.execute("DELETE FROM cart")
        conn.commit()
    db.sync_roots(conn, cfg)
    return entry


def needs_setup(conn):
    """没配过库，或者配了但一个都找不到 -> 走引导。"""
    rows = list(conn.execute("SELECT * FROM roots WHERE enabled=1"))
    if not rows:
        return True
    return not any(os.path.isdir(db.root_abspath(r)) for r in rows)
