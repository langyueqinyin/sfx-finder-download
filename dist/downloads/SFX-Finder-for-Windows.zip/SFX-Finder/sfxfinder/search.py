"""搜索：FTS5 主路径 + CJK/短词 LIKE 回退 + 编号前缀直查。"""
import re
import unicodedata

CJK = re.compile(r"[㐀-䶿一-鿿぀-ヿ가-힯]")
CODE_QUERY = re.compile(r"^[A-Za-z]{1,8}[-_]?\d{1,4}([-_]\d{1,3})*$")

SELECT = """
SELECT a.id, a.rel_path, a.filename, a.stem, a.ext, a.folder_path, a.library,
       a.size, a.duration_ms, a.samplerate, a.channels, a.probed_at, a.duration_src,
       a.catalog_desc, a.embedded_desc, a.category, a.code,
       r.label AS root_label,
       (SELECT 1 FROM cart WHERE cart.asset_id = a.id) AS in_cart
FROM assets a JOIN roots r ON r.id = a.root_id
"""


def tokenize(q):
    """拆词，尊重双引号短语。"""
    return [t for t in re.findall(r'"([^"]+)"|(\S+)', q) for t in t if t]


def fts_query(q):
    parts = []
    for tok in tokenize(q):
        tok = tok.replace('"', '""')
        parts.append(f'"{tok}"*' if " " not in tok else f'"{tok}"')
    return " AND ".join(parts)


def _filters(library, ext, dur_min, dur_max, has_desc):
    where, args = [], []
    if library:
        where.append("a.library = ?")
        args.append(library)
    if ext:
        where.append("a.ext = ?")
        args.append(ext if ext.startswith(".") else "." + ext)
    if dur_min is not None:
        where.append("a.duration_ms >= ?")
        args.append(int(dur_min))
    if dur_max is not None:
        where.append("a.duration_ms <= ?")
        args.append(int(dur_max))
    if has_desc:
        where.append("a.catalog_desc IS NOT NULL")
    return where, args


def search(conn, q, library=None, ext=None, dur_min=None, dur_max=None,
           has_desc=False, sort="relevance", limit=200, offset=0, with_count=True):
    """with_count=False 时跳过精确计数。大结果集（door 命中 1778 条）上
    count(*) 才是耗时大头，而推荐词只需要采样，不需要总数。"""
    q = unicodedata.normalize("NFC", (q or "").strip())
    where, args = _filters(library, ext, dur_min, dur_max, has_desc)
    where.append("a.status = 'ok'")

    def count(w, a):
        return _count(conn, w, a) if with_count else None

    if not q:
        sql = SELECT + " WHERE " + " AND ".join(where)
        order = {"duration": "a.duration_ms", "name": "a.filename"}.get(sort, "a.id")
        sql += f" ORDER BY {order} LIMIT ? OFFSET ?"
        rows = conn.execute(sql, args + [limit, offset]).fetchall()
        return [dict(r) for r in rows], count(where, args)

    # 编号直查：SI-4001 这种，直接前缀定位整张盘
    if CODE_QUERY.match(q):
        code = q.strip().upper().replace("-", "_")
        w = where + ["a.code LIKE ?"]
        a = args + [code + "%"]
        sql = SELECT + " WHERE " + " AND ".join(w) + " ORDER BY a.code LIMIT ? OFFSET ?"
        rows = conn.execute(sql, a + [limit, offset]).fetchall()
        if rows:
            return [dict(r) for r in rows], count(w, a)

    # CJK 或极短词：FTS5 的 unicode61 分不了中文，走 LIKE
    if CJK.search(q) or min((len(t) for t in tokenize(q)), default=9) < 2:
        w = list(where)
        a = list(args)
        for tok in tokenize(q):
            w.append("a.search_text LIKE ?")
            a.append(f"%{tok.lower()}%")
        sql = SELECT + " WHERE " + " AND ".join(w) + " ORDER BY a.filename LIMIT ? OFFSET ?"
        rows = conn.execute(sql, a + [limit, offset]).fetchall()
        return [dict(r) for r in rows], count(w, a)

    # 主路径：FTS5，描述命中权重 10 > 文件名 5 > 路径 1
    return _fts(conn, q, fts_query(q), where, args, sort, limit, offset, count)


def _fts(conn, q, expr, where, args, sort, limit, offset, count):
    w = where + ["a.id IN (SELECT rowid FROM assets_fts WHERE assets_fts MATCH ?)"]
    a = args + [expr]
    order = {
        "duration": "a.duration_ms",
        "name": "a.filename",
    }.get(sort) or ("(SELECT bm25(assets_fts, 10.0, 5.0, 1.0) FROM assets_fts "
                    "WHERE rowid = a.id AND assets_fts MATCH ?)")
    sql = SELECT + " WHERE " + " AND ".join(w) + f" ORDER BY {order} LIMIT ? OFFSET ?"
    params = a + ([limit, offset] if sort in ("duration", "name") else [expr, limit, offset])
    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows], count(w, a)


# 放宽到一定程度就没意义了：只剩一个宽泛的词时结果能有上千条，但全不相关。
# 搜 body hit ground，剩 body+ground 给 3 条 bodyfall 是有用的，剩 ground 给
# 1191 条马蹄和风声是没用的。超过这个数就认为这次放宽已经放过头。
LOOSE_CAP = 400


def search_loose(conn, q, min_hits=3, **kw):
    """精确搜不到（或搜得太少）时，逐级放宽再搜一次。

    返回 (rows, total, relax)。relax 为 None 表示这是精确结果，界面不用提示；
    否则里面写清楚实际用了哪些词、丢了哪个词，别让人以为这就是精确匹配。
    """
    from . import expand

    limit = kw.get("limit", 100)
    rows, total = search(conn, q, **kw)
    # 用总命中数判断够不够，不能用 len(rows)——那是被 limit 截断后的数字，
    # limit 小的时候会永远判定「不够」而无限放宽。
    if (total or 0) >= min_hits or not q.strip():
        return rows, total, None

    concepts = expand.build_concepts(conn, q)
    if not concepts:
        return rows, total, None
    words = [c["orig"] for c in concepts]

    # plans 是由严到松排的。要的是「最严格的、既够数又不至于宽到没意义的那个」；
    # 一个都不够数时，退回最严格的非空结果——3 条精准的胜过上千条不相关的。
    strictest_nonempty = None
    for plan in expand.relaxation_plan(concepts):
        expr = expand.fts_expr(plan)
        where, args = _filters(kw.get("library"), kw.get("ext"), kw.get("dur_min"),
                               kw.get("dur_max"), kw.get("has_desc", False))
        where.append("a.status = 'ok'")
        try:
            r2, t2 = _fts(conn, q, expr, where, args, kw.get("sort", "relevance"),
                          limit, kw.get("offset", 0),
                          lambda ww, aa: _count(conn, ww, aa))
        except Exception:
            continue
        if not t2:
            continue
        cand = (r2, t2, dict(expand.describe(plan, words),
                             exact=False, kept=len(plan), total_concepts=len(concepts)))
        if strictest_nonempty is None:
            strictest_nonempty = cand
        if min_hits <= t2 <= LOOSE_CAP:
            return cand
    return strictest_nonempty or (rows, total, None)


def collapse_dupes(rows, limit):
    """把描述完全相同的结果折叠成一组。

    这些老音效库里，同一条 track 的多个 index 共用一条描述（AT-06_76_01 / _02 /
    AT-06_78_01 全是 "RATTLESNAKE, MOJAVE TAIL RATTLES..."），不折叠的话搜 rattle
    前二十条会是同一句话，翻半天看不到别的声音。但它们确实是不同的 take，所以是
    折叠不是丢弃——每组留一条代表，其余挂在 dupes 里，前端点开就能听。
    """
    groups, order, consumed = {}, [], 0
    for i, r in enumerate(rows):
        key = (r.get("catalog_desc") or r["filename"]).strip().lower()
        if key not in groups:
            if len(order) >= limit:
                break          # 够一屏了，剩下的留给「加载更多」
            groups[key] = dict(r, dupes=[], dupe_n=1)
            order.append(key)
        else:
            g = groups[key]
            g["dupe_n"] += 1
            if len(g["dupes"]) < 40:
                g["dupes"].append(r)
        consumed = i + 1
    return [groups[k] for k in order], consumed


def _count(conn, where, args):
    sql = "SELECT count(*) n FROM assets a WHERE " + " AND ".join(where)
    return conn.execute(sql, args).fetchone()["n"]


def facets(conn, q=None):
    """左侧筛选用的库列表。"""
    return [dict(r) for r in conn.execute(
        "SELECT library, count(*) n FROM assets WHERE status='ok' "
        "GROUP BY library ORDER BY n DESC"
    )]
