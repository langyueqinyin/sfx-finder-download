"""Pass C：通用对照表嗅探器。

不针对某一张表写死。核心思路是**用「该列的值有多少能对上磁盘上真实的文件名」来给列打分**，
而不是去猜表头叫什么。这样列顺序变了、表头改了、换成别人的库，都照样能自动找对列。
（在 SFX_DB.xls 上实测：编号列得 39118 分，其他列全 0 分，区分度极高。）
"""
import csv
import os
import re
import time

from . import config, db
from .scanner import norm_code

TIME_RE = re.compile(r"^\s*(\d{0,3}):(\d{2})\s*$")
CODEISH_RE = re.compile(r"^[A-Z0-9]{1,8}[_-]\d{1,4}([_-]\d{1,3}){1,3}$")


def code_variants(code):
    """一个编号的等价写法。磁盘和表格之间常差前导零。"""
    out = {code}
    parts = code.split("_")
    if len(parts) > 1:
        stripped = [parts[0]] + [p.lstrip("0") or "0" if p.isdigit() else p for p in parts[1:]]
        out.add("_".join(stripped))
        padded = [parts[0]] + [p.zfill(2) if p.isdigit() else p for p in parts[1:]]
        out.add("_".join(padded))
    return out


def parse_duration(v):
    """':01' / '1:23' -> 毫秒。裸数字不认——含义没法确定，交给懒探测更靠谱。"""
    m = TIME_RE.match(str(v or ""))
    if not m:
        return None
    mins = int(m.group(1) or 0)
    return (mins * 60 + int(m.group(2))) * 1000


# ---------------------------------------------------------------- 表格读取

def _xls_cell(sh, r, c):
    """xls 单元格取值，顺手修一个老目录表的坑。

    SFX_DB.xls 的 TIME 列混了三种类型：36832 行是文本 ':01'，5150 行是 Excel
    日期序列值。后者是当年录入 '1:47'（1分47秒）时被 Excel 当成 1小时47分存下的，
    所以 value * 1440 得到的「分钟数」实际是秒数——已用 4 个真实文件核对过
    （107→110s、96→98.8s、139→141.95s、180→182.7s）。这里统一还原成 'm:ss'
    文本，下游就只需要认一种格式。
    """
    import xlrd
    if sh.cell_type(r, c) == xlrd.XL_CELL_DATE:
        total = round(sh.cell_value(r, c) * 1440)
        return f"{total // 60}:{total % 60:02d}"
    return sh.cell_value(r, c)


def read_sheets(path):
    """产出 (sheet_name, rows)。rows 是 list[list[cell]]，统一成 python 值。"""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".xls":
        import xlrd
        bk = xlrd.open_workbook(path)
        for name in bk.sheet_names():
            sh = bk.sheet_by_name(name)
            yield name, [[_xls_cell(sh, r, c) for c in range(sh.ncols)]
                         for r in range(sh.nrows)]
    elif ext == ".xlsx":
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        for ws in wb.worksheets:
            yield ws.title, [list(row) for row in ws.iter_rows(values_only=True)]
        wb.close()
    elif ext == ".csv":
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as f:
            sample = f.read(8192)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample)
            except csv.Error:
                dialect = csv.excel
            yield os.path.basename(path), [row for row in csv.reader(f, dialect)]


def find_catalog_files(abs_root, exts):
    found = []
    stack = [abs_root]
    while stack:
        try:
            it = os.scandir(stack.pop())
        except OSError:
            continue
        with it:
            for e in it:
                if e.name.startswith("._") or e.name in config.SKIP_NAMES:
                    continue
                if e.is_dir(follow_symlinks=False):
                    stack.append(e.path)
                elif os.path.splitext(e.name)[1].lower() in exts:
                    found.append(e.path)
    return found


# ---------------------------------------------------------------- 列嗅探

def _cell_str(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def sniff_columns(rows, disk_index):
    """返回 (code_col, desc_col, time_col, hit, header_row)。找不到返回 None。"""
    if len(rows) < 2:
        return None
    ncols = max(len(r) for r in rows)
    # 表头行：第一行若几乎全是短文本且下一行不是，则当表头
    header_row = 0 if rows and all(isinstance(v, str) for v in rows[0] if v not in (None, "")) else -1
    body = rows[header_row + 1:]

    best_code, best_hit = None, 0
    col_vals = []
    for c in range(ncols):
        vals = set()
        for r in body:
            if c < len(r):
                s = _cell_str(r[c]).strip()
                if s:
                    vals.add(norm_code(s))
        col_vals.append(vals)
        hit = sum(1 for v in vals if v in disk_index)
        if hit > best_hit:
            best_code, best_hit = c, hit
    if best_code is None or best_hit == 0:
        return None

    # 描述列：排除编号列，取「平均长度 × 唯一度」最高的字符串列。
    # 只看平均长度会踩坑——URL 列往往最长，但整列只有一两个值，显然不是描述。
    best_desc, best_score = None, 0
    for c in range(ncols):
        if c == best_code:
            continue
        sample = [_cell_str(r[c]).strip() for r in body[:5000] if c < len(r)]
        sample = [s for s in sample if s]
        if len(sample) < 2:
            continue
        avg = sum(len(s) for s in sample) / len(sample)
        uniq_ratio = len(set(sample)) / len(sample)
        if avg < 4 or uniq_ratio < 0.1:
            continue
        score = avg * min(1.0, uniq_ratio / 0.3)
        if score > best_score:
            best_desc, best_score = c, score
    if best_desc is None:
        return None

    # 时长列：多数值形如 :ss / m:ss
    best_time = None
    for c in range(ncols):
        if c in (best_code, best_desc):
            continue
        vals = [_cell_str(r[c]) for r in body[:500] if c < len(r)]
        vals = [v for v in vals if v.strip()]
        if vals and sum(1 for v in vals if TIME_RE.match(v)) / len(vals) > 0.8:
            best_time = c
            break

    header = [_cell_str(v) for v in rows[header_row]] if header_row >= 0 else []
    return best_code, best_desc, best_time, best_hit, header


# ---------------------------------------------------------------- 导入

def import_catalogs(conn, verbose=True):
    cfg = config.load()
    exts = set(cfg["catalog_ext"])

    disk_index = {}
    for row in conn.execute("SELECT DISTINCT code FROM assets WHERE status='ok' AND code IS NOT NULL"):
        for v in code_variants(row["code"]):
            disk_index.setdefault(v, row["code"])
    if verbose:
        print(f"[catalog] 磁盘编号索引: {len(disk_index)} 个变体")

    candidates = []
    for root_row in conn.execute("SELECT * FROM roots WHERE enabled = 1"):
        abs_root = db.root_abspath(root_row)
        if not os.path.isdir(abs_root):
            continue
        for path in find_catalog_files(abs_root, exts):
            rel = os.path.relpath(path, abs_root)
            try:
                sheets = list(read_sheets(path))
            except Exception as e:
                if verbose:
                    print(f"[catalog] 读不了 {rel}: {e}")
                continue
            for sheet_name, rows in sheets:
                sniffed = sniff_columns(rows, disk_index)
                if sniffed and sniffed[3] >= 10:  # hit < 10 视为噪音
                    candidates.append((rel, sheet_name, rows, sniffed))

    # 命中多的表先写。同一个编号被多张表覆盖时，权威表（命中最多的）说了算。
    candidates.sort(key=lambda x: -x[3][3])

    reports = []
    for rel, sheet_name, rows, (code_c, desc_c, time_c, hit, header) in candidates:
        def hdr(c):
            return header[c] if c is not None and c < len(header) else f"col{c}"
        n = _load_rows(conn, rows, code_c, desc_c, time_c, disk_index, rel)
        reports.append({
            "file": rel, "sheet": sheet_name, "rows": len(rows),
            "code_col": hdr(code_c), "desc_col": hdr(desc_c),
            "time_col": hdr(time_c) if time_c is not None else None,
            "matched": n,
        })
        if verbose:
            tcol = repr(hdr(time_c)) if time_c is not None else "无"
            print(f"[catalog] {rel} :: {sheet_name}")
            print(f"    编号列={hdr(code_c)!r} 描述列={hdr(desc_c)!r} "
                  f"时长列={tcol} -> 新写入 {n} 条")
    conn.commit()
    apply_catalog(conn, verbose=verbose)
    return reports


def _load_rows(conn, rows, code_c, desc_c, time_c, disk_index, source):
    """描述为空时向下继承上一条——这类目录表的惯例：连续音轨共用一条描述。"""
    written = 0
    last_desc = ""
    for r in rows[1:]:
        if code_c >= len(r):
            continue
        raw = _cell_str(r[code_c]).strip()
        if not raw:
            continue
        desc = _cell_str(r[desc_c]).strip() if desc_c < len(r) else ""
        if desc:
            last_desc = desc
        else:
            desc = last_desc
        if not desc:
            continue
        canon = None
        for v in code_variants(norm_code(raw)):
            if v in disk_index:
                canon = disk_index[v]
                break
        if canon is None:
            continue
        dur = parse_duration(r[time_c]) if time_c is not None and time_c < len(r) else None
        desc = re.sub(r"\s{2,}", " — ", desc).strip()
        # 分类 = 描述的第一个逗号段，但只在它短到确实像个分类名时才算。
        # 很多描述本身就带逗号（"...SHOES ON METAL GRATE, MEDIUM"），不加长度限制
        # 会把整句话当成分类。
        category = None
        if "," in desc:
            head = desc.split(",")[0].strip()
            if 2 <= len(head) <= 30:
                category = head
        cur = conn.execute(
            "INSERT INTO catalog (code, description, duration_ms, category, source_file) "
            "VALUES (?,?,?,?,?) ON CONFLICT(code) DO NOTHING",
            (canon, desc, dur, category, source),
        )
        written += cur.rowcount
    return written


def apply_catalog(conn, verbose=True):
    """把 catalog 回填到 assets，并打印命中率（唯一的硬指标）。"""
    now = time.time()
    conn.execute(
        """UPDATE assets SET
               catalog_desc = (SELECT description FROM catalog c WHERE c.code = assets.code),
               category     = (SELECT category    FROM catalog c WHERE c.code = assets.code)
           WHERE code IN (SELECT code FROM catalog)"""
    )
    # Excel 自带时长的，直接白赚，不用再 open 文件探测
    conn.execute(
        """UPDATE assets SET
               duration_ms  = (SELECT duration_ms FROM catalog c WHERE c.code = assets.code),
               duration_src = 'catalog',
               probed_at    = ?
           WHERE duration_ms IS NULL
             AND code IN (SELECT code FROM catalog WHERE duration_ms IS NOT NULL)""",
        (now,),
    )
    conn.execute(
        """UPDATE assets SET search_text =
               lower(filename || ' ' || folder_path || ' ' || library || ' '
                     || COALESCE(catalog_desc, '') || ' ' || COALESCE(embedded_desc, ''))"""
    )
    conn.commit()
    db.rebuild_fts(conn)

    if verbose:
        tot = conn.execute("SELECT count(*) n FROM assets WHERE status='ok'").fetchone()["n"]
        if not tot:            # 空库（选错目录、或扫描失败）时别在算命中率时崩掉
            print("[catalog] 库里一条素材都没有，跳过对照表回填")
            return
        hit = conn.execute(
            "SELECT count(*) n FROM assets WHERE status='ok' AND catalog_desc IS NOT NULL"
        ).fetchone()["n"]
        dur = conn.execute(
            "SELECT count(*) n FROM assets WHERE status='ok' AND duration_ms IS NOT NULL"
        ).fetchone()["n"]
        print(f"\n[catalog] 全库 {tot} 条，{hit} 条拿到描述（{hit/tot*100:.1f}%），"
              f"{dur} 条时长直接来自对照表")
        for r in conn.execute(
            """SELECT library, count(*) n,
                      sum(catalog_desc IS NOT NULL) hit
               FROM assets WHERE status='ok' GROUP BY library
               HAVING hit > 0 AND n > 0 ORDER BY n DESC"""
        ):
            print(f"    {r['library']}: {r['hit']}/{r['n']} ({r['hit']/r['n']*100:.1f}%)")
