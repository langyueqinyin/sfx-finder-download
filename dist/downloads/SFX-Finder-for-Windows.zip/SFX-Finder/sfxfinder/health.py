"""坏账报告：库里哪些东西其实是废的。

用户原话是「有的无效了，有的丢了」。实测这块盘上有四类：
  - 0 字节的空壳文件（298 个，一多半在 CAMP From Pro Sound Library）
  - Sound Designer II 的 .L/.R 拆分立体声（1107 组），现在的播放器都放不了
  - 只有 Avid bin（.avb）没有真音频的目录（NEILS_FX，742 个条目）
  - 空目录（RI SFX / 20th Century Fox 等）
"""
import os

from . import config, db


def _scan_dirs(abs_root, audio_ext):
    """返回 {rel_dir: {'audio': n, 'other': n, 'bins': n, 'subdirs': n}}"""
    stats = {}
    for dirpath, dirnames, filenames in os.walk(abs_root):
        dirnames[:] = [d for d in dirnames
                       if not d.startswith("._") and d not in config.SKIP_NAMES]
        rel = os.path.relpath(dirpath, abs_root)
        rel = "" if rel == "." else rel
        n_audio = n_other = n_bin = n_doc = 0
        for fn in filenames:
            if fn.startswith("._") or fn in config.SKIP_NAMES:
                continue
            ext = os.path.splitext(fn)[1].lower()
            if ext in audio_ext:
                n_audio += 1
            elif ext in (".avb", ".lck"):
                n_bin += 1
            elif ext in (".xls", ".xlsx", ".csv", ".pdf", ".txt", ".doc", ".docx"):
                n_doc += 1          # 对照表/说明书目录，不是废目录
            else:
                n_other += 1
        stats[rel] = {"audio": n_audio, "other": n_other, "bins": n_bin,
                      "docs": n_doc, "subdirs": len(dirnames)}
    return stats


def report(conn, deep=True):
    cfg = config.load()
    audio_ext = set(cfg["audio_ext"])

    out = {
        "zero_byte": [],
        "unsupported": [],
        "missing": [],
        "empty_dirs": [],
        "bin_only_dirs": [],
        "totals": {},
    }

    for key, status in (("zero_byte", "zero_byte"), ("unsupported", "unsupported"),
                        ("missing", "missing")):
        out["totals"][key] = conn.execute(
            "SELECT count(*) n FROM assets WHERE status=?", (status,)).fetchone()["n"]
        out[key] = [dict(r) for r in conn.execute(
            "SELECT library, folder_path, count(*) n FROM assets WHERE status=? "
            "GROUP BY library, folder_path ORDER BY n DESC LIMIT 40", (status,))]

    out["totals"]["ok"] = conn.execute(
        "SELECT count(*) n FROM assets WHERE status='ok'").fetchone()["n"]

    if not deep:
        return out

    for root_row in conn.execute("SELECT * FROM roots WHERE enabled=1"):
        abs_root = db.root_abspath(root_row)
        if not os.path.isdir(abs_root):
            continue
        stats = _scan_dirs(abs_root, audio_ext)

        # 子孙合计。判断一个目录是否「废」必须看整棵子树：NEILS_FX 顶层一个文件都没有，
        # 真正的 742 个 Avid bin 全埋在下面几层，只看本层会把它误判成空目录。
        def totals_below(key):
            agg = {"audio": 0, "bins": 0, "docs": 0, "other": 0}
            for path, st in stats.items():
                if path == key or (path.startswith(key + "/") if key else True):
                    for k in agg:
                        agg[k] += st[k]
            return agg

        below = {rel: totals_below(rel) for rel in stats}

        for rel, st in stats.items():
            b = below[rel]
            if b["audio"] > 0 or not rel:
                continue
            parent = rel.rsplit("/", 1)[0] if "/" in rel else ""
            if below.get(parent, {"audio": 1})["audio"] == 0:
                continue  # 只报最顶层那个，不把整棵空树都列出来
            entry = {"root": root_row["label"], "path": rel,
                     "bins": b["bins"], "other": b["other"]}
            if b["bins"] > 0:
                out["bin_only_dirs"].append(entry)
            elif b["docs"] == 0:      # 只放对照表/说明书的目录不算废
                out["empty_dirs"].append(entry)

    out["bin_only_dirs"].sort(key=lambda e: -e["bins"])
    out["empty_dirs"].sort(key=lambda e: e["path"])
    return out
