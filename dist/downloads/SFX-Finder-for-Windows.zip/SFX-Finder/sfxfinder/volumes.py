"""盘符检测、换盘、以及跟系统打交道的那几件事（选目录、在文件管理器里定位）。

macOS 是主力，Windows 做到能用：原生目录选择器在 Mac 上走 osascript、
Windows 上走 PowerShell 的 FolderBrowserDialog；定位文件 Mac 用 `open -R`、
Windows 用 `explorer /select,`。
"""
import os
import string
import subprocess
import sys

from . import config, db

IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"


# ------------------------------------------------- 盘 / 卷

def list_volumes():
    """可能装着素材库的挂载点。"""
    if IS_WIN:
        out = []
        for letter in string.ascii_uppercase:
            root = f"{letter}:\\"
            if os.path.isdir(root):
                out.append(root)
        return out
    out = []
    for base in ("/Volumes", "/media", "/mnt"):
        try:
            out += [os.path.join(base, n) for n in sorted(os.listdir(base))
                    if not n.startswith(".")]
        except OSError:
            continue
    return out


def split_base(path):
    """把绝对路径拆成 (基准路径, 库内相对路径)。

    拆在盘的边界上，这样换盘时只需要改前半段，索引里的相对路径原样可用。
    拆不出来（比如库放在系统盘的某个目录里）就整条当基准路径。
    """
    path = os.path.abspath(path).rstrip("/\\")
    if IS_WIN:
        drive, rest = os.path.splitdrive(path)
        if drive:
            return drive + "\\", rest.lstrip("\\/")
        return path, ""
    for base in ("/Volumes", "/media", "/mnt"):
        prefix = base + "/"
        if path.startswith(prefix):
            rest = path[len(prefix):]
            vol, _, inner = rest.partition("/")
            return os.path.join(base, vol), inner
    return path, ""


def volume_label(base_path):
    return os.path.basename(base_path.rstrip("/\\")) or base_path


def root_status(conn):
    out = []
    for r in conn.execute("SELECT * FROM roots WHERE enabled = 1"):
        abs_root = db.root_abspath(r)
        probe = os.path.join(abs_root, r["probe_file"]) if r["probe_file"] else abs_root
        out.append({
            "id": r["id"], "label": r["label"],
            "volume": r["volume_name"], "base_path": r["base_path"],
            "rel_root": r["rel_root"], "path": abs_root,
            "mounted": os.path.isdir(abs_root),
            "verified": os.path.exists(probe),
            "n_assets": conn.execute(
                "SELECT count(*) n FROM assets WHERE root_id=? AND status='ok'",
                (r["id"],)).fetchone()["n"],
        })
    return out


def find_candidates(conn, root_id):
    """这块盘没挂载时，看看别的盘里有没有一模一样的目录结构。"""
    r = conn.execute("SELECT * FROM roots WHERE id=?", (root_id,)).fetchone()
    if r is None:
        return []
    hits = []
    for base in list_volumes():
        cand = os.path.join(base, r["rel_root"]) if r["rel_root"] else base
        if not os.path.isdir(cand):
            continue
        probe = os.path.join(cand, r["probe_file"]) if r["probe_file"] else cand
        hits.append({"volume": volume_label(base), "base_path": base,
                     "path": cand, "verified": os.path.exists(probe)})
    hits.sort(key=lambda h: (not h["verified"], h["volume"]))
    return hits


def repoint(conn, root_id, base_path):
    r = conn.execute("SELECT * FROM roots WHERE id=?", (root_id,)).fetchone()
    conn.execute("UPDATE roots SET base_path=?, volume_name=? WHERE id=?",
                 (base_path, volume_label(base_path), root_id))
    conn.commit()
    cfg = config.load()                    # 同步回 config.json，保持可手改
    for entry in cfg["roots"]:
        if entry["label"] == r["label"]:
            entry["base"] = base_path
            entry["volume"] = volume_label(base_path)
    config.save(cfg)
    return root_status(conn)


# ------------------------------------------------- 跟系统打交道

def choose_folder(prompt="选择文件夹"):
    """浏览器拿不到真实路径，只能让后端弹系统的目录选择器。"""
    try:
        if IS_MAC:
            script = f'POSIX path of (choose folder with prompt "{prompt}")'
            p = subprocess.run(["osascript", "-e", script],
                               capture_output=True, text=True, timeout=300)
            path = p.stdout.strip()
            return path.rstrip("/") if path else None
        if IS_WIN:
            ps = (
                "Add-Type -AssemblyName System.Windows.Forms;"
                "$d = New-Object System.Windows.Forms.FolderBrowserDialog;"
                f"$d.Description = '{prompt}';"
                "if ($d.ShowDialog() -eq 'OK') { Write-Output $d.SelectedPath }"
            )
            p = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps],
                               capture_output=True, text=True, timeout=300)
            path = p.stdout.strip()
            return path or None
    except (OSError, subprocess.SubprocessError):
        return None
    return None                            # Linux：界面上手填路径


def reveal(path):
    """在文件管理器里选中这个文件。"""
    if not os.path.exists(path):
        return False
    try:
        if IS_MAC:
            subprocess.Popen(["open", "-R", path])
        elif IS_WIN:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        else:
            subprocess.Popen(["xdg-open", os.path.dirname(path)])
    except OSError:
        return False
    return True


def open_dir(path):
    if not os.path.isdir(path):
        return False
    try:
        subprocess.Popen(["open", path] if IS_MAC else
                         ["explorer", os.path.normpath(path)] if IS_WIN else
                         ["xdg-open", path])
    except OSError:
        return False
    return True
