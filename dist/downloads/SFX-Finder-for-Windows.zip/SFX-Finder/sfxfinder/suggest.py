"""近义词 / 相关词推荐。

核心不是查词典，而是**从用户自己这 4.7 万条库里挖**：搜 rattle 命中 543 条，
看这 543 条的描述里还高频出现哪些别的词，按 lift（该词在命中集里的密度 ÷ 在全库的
密度）排序——这样 CHAIN / KEYS / SNAKE 会浮上来，而 SOUND / EFFECT 这种全库
到处都是的词会被压下去。

好处是推荐的每个词点下去都保证有结果，而且完全离线、瞬时。
词典只在挖不出东西时兜底，且同样先查一遍有没有结果。
"""
import json
import os
import re
from collections import Counter

from . import config, search

WORD = re.compile(r"[a-z]{3,}")   # 纯字母，避免把 sdt- 这类碟片前缀当成词
SYN_PATH = os.path.join(config.DATA_DIR, "sfx_synonyms.json")

STOPWORDS = {
    "the", "and", "with", "for", "from", "out", "off", "into", "then", "than", "that", "this",
    "his", "her", "its", "was", "are", "has", "have", "not", "but", "all", "one", "two", "three",
    "sound", "sounds", "effect", "effects", "audio", "track", "tracks", "file", "wav", "mp3",
    "aiff", "aif", "mix", "stereo", "mono", "version", "take", "int", "ext", "amb",
    "close", "medium", "long", "short", "single", "double", "several", "various", "misc",
    "perspective", "background", "foreground", "series", "sequence", "loop", "loopable",
    "cont", "constant", "steady", "slow", "fast", "high", "low", "big", "small", "light", "heavy",
    "new", "old", "sfx", "designed", "elements", "element",
}

# 碟片编号（PE-33 / SDT-02 / WORKS-03），是目录结构不是分类，别拿来当细分类型
DISC_CODE = re.compile(r"^[A-Za-z]{1,8}[-_]?\d{1,4}$")

_syn_cache = None


def stem(w):
    """够用的词干化，目的只是把 rattle/rattles/rattling 归成一组。"""
    for suf, repl in (("ies", "y"), ("ing", ""), ("ed", ""), ("es", ""), ("s", "")):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            base = w[: -len(suf)] + repl
            # running -> runn -> run
            if suf in ("ing", "ed") and len(base) > 3 and base[-1] == base[-2]:
                base = base[:-1]
            return base
    return w


def is_variant(word, query_words):
    """rattley / rattly / rattles 之于 rattle：占着推荐位却不给新信息。"""
    ws = stem(word)
    for q in query_words:
        if ws == stem(q):
            return True
        if (word.startswith(q) or q.startswith(word)) and abs(len(word) - len(q)) <= 3:
            return True
    return False


def _synonyms():
    global _syn_cache
    if _syn_cache is None:
        with open(SYN_PATH, encoding="utf-8") as f:
            _syn_cache = {k: v for k, v in json.load(f).items() if not k.startswith("_")}
    return _syn_cache


def build_term_stats(conn, verbose=True):
    """全库词表：每个词出现在多少条素材里。索引后跑一次，几秒钟。

    这里**不过滤停用词**——词频表是数据，停用词是展示层的策略。
    推荐词那边照样会滤掉 heavy / light 这类，但查询扩展（expand.py）需要知道
    它们的真实频次才能判断该丢哪个词；过滤掉会让它们 df=0，被误判成生僻词保留下来。
    """
    df = Counter()
    for row in conn.execute(
        "SELECT COALESCE(catalog_desc,'') || ' ' || filename || ' ' || folder_path AS t "
        "FROM assets WHERE status='ok'"
    ):
        for w in set(WORD.findall(row["t"].lower())):
            df[w] += 1
    conn.execute("DELETE FROM term_stats")
    conn.executemany("INSERT INTO term_stats (term, df) VALUES (?,?)", df.items())
    conn.commit()
    if verbose:
        print(f"[suggest] 词表: {len(df)} 个词")
    return len(df)


def related_terms(conn, q, library=None, limit=12, sample=300):
    """返回 {'terms': [...], 'categories': [...]}"""
    q = (q or "").strip()
    if not q:
        return {"terms": [], "categories": []}

    rows, _ = search.search(conn, q, library=library, limit=sample, with_count=False)
    if not rows:
        return {"terms": [], "categories": []}

    query_words = set(WORD.findall(q.lower()))
    n = len(rows)
    cf = Counter()          # 按词干计数
    best_form = {}          # 词干 -> 展示用的那个词形（取全库最常见的）
    cats = Counter()
    for r in rows:
        text = f"{r['catalog_desc'] or ''} {r['filename']} {r['folder_path']}".lower()
        seen_stems = set()
        for w in set(WORD.findall(text)):
            if w in STOPWORDS or is_variant(w, query_words):
                continue
            s = stem(w)
            if s not in seen_stems:
                cf[s] += 1
                seen_stems.add(s)
            best_form.setdefault(s, Counter())[w] += 1
        cat = r["category"]
        if not cat:
            leaf = (r["folder_path"] or "").rsplit("/", 1)[-1]
            cat = leaf if leaf and not DISC_CODE.match(leaf) else None
        # 带冒号/破折号的是完整描述不是分类名（"COMPUTER: CD ROM DOOR OPEN"）
        if cat and len(cat) <= 30 and not any(ch in cat for ch in ":—;"):
            cats[cat] += 1

    total_docs = conn.execute(
        "SELECT count(*) n FROM assets WHERE status='ok'").fetchone()["n"] or 1

    # 每个词干用它在命中集里最常见的词形去展示和查全库频次
    display = {s: forms.most_common(1)[0][0] for s, forms in best_form.items()}
    words = set(display.values())
    dfs = {}
    if words:
        qs = ",".join("?" * len(words))
        dfs = {r["term"]: r["df"] for r in conn.execute(
            f"SELECT term, df FROM term_stats WHERE term IN ({qs})", list(words))}

    scored = []
    for s, c in cf.items():
        if c < 3 or c / n < 0.02:
            continue
        w = display[s]
        d = dfs.get(w, 0)
        if d < 5:
            continue
        lift = (c / n) / (d / total_docs)
        if lift < 1.5:
            continue
        scored.append((lift * (1 + c) ** 0.3, w, d))
    scored.sort(reverse=True)
    terms = [{"term": w, "count": d} for _, w, d in scored[:limit]]

    # 词典兜底：共现挖不够时补，且只留库里真有结果的
    if len(terms) < 5:
        have = {t["term"] for t in terms} | query_words
        for qw in query_words:
            for cand in _synonyms().get(qw, []):
                if cand in have:
                    continue
                hits, c = search.search(conn, cand, library=library, limit=1)
                if hits:
                    terms.append({"term": cand, "count": c, "from_dict": True})
                    have.add(cand)
                if len(terms) >= limit:
                    break

    categories = [{"name": c, "count": k} for c, k in cats.most_common(10) if k >= 2]
    return {"terms": terms, "categories": categories, "sampled": n}
