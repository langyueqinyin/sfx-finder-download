"""拷贝到项目文件夹。这是整个工具唯一的写操作，所以：只 copy 不 move，
默认不覆盖同名文件，每次都记 copy_log。"""
import json
import os
import re
import shutil
import time

from . import db

# 除了文件系统真正禁止的字符，标点也一并转掉——目录表的描述里全是
# "GLASS BREAK; SINGLE GLASS BREAK, CRASH. CLOSE-UP." 这种，原样塞进文件名
# 会得到一串分号逗号句号，在 Premiere 素材箱里很难读。连字符保留（BB-04 要用）。
ILLEGAL = re.compile(r'[/\\:*?"<>|;,.\x00-\x1f]')
MAX_DESC = 110


def _umask():
    m = os.umask(0)
    os.umask(m)
    return m


def safe_component(s, maxlen=MAX_DESC):
    s = ILLEGAL.sub(" ", s or "").strip()
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"_{2,}", "_", s).strip("._-")
    return s[:maxlen].rstrip("._-") or "untitled"


def folder_from_query(query):
    """搜索词 -> 目录名。rattle -> Rattle，glass break -> Glass_Break"""
    name = safe_component(query, 60)
    return "_".join(w[:1].upper() + w[1:] for w in name.split("_") if w)


def target_name(row, naming_mode):
    stem, ext = os.path.splitext(row["filename"])
    if naming_mode == "desc_orig":
        desc = row["catalog_desc"] or row["embedded_desc"]
        if desc:
            return f"{safe_component(desc)}__{stem}{ext}"
    return row["filename"]


def _resolve_conflict(path, on_conflict):
    """返回最终路径，或 None 表示跳过。"""
    if not os.path.exists(path):
        return path
    if on_conflict == "skip":
        return None
    base, ext = os.path.splitext(path)
    for i in range(2, 1000):
        cand = f"{base}_{i}{ext}"
        if not os.path.exists(cand):
            return cand
    return None


def copy_assets(conn, ids, dest_root, subfolder="", naming_mode="desc_orig",
                preserve_tree=False, on_conflict="suffix"):
    dest_dir = os.path.join(os.path.expanduser(dest_root), subfolder) if subfolder \
        else os.path.expanduser(dest_root)
    os.makedirs(dest_dir, exist_ok=True)

    qs = ",".join("?" * len(ids))
    rows = conn.execute(f"SELECT * FROM assets WHERE id IN ({qs})", list(ids)).fetchall()
    by_id = {r["id"]: r for r in rows}

    detail, n_ok, n_skip, n_fail = [], 0, 0, 0
    for aid in ids:                       # 保持用户勾选的顺序
        row = by_id.get(aid)
        if row is None:
            n_fail += 1
            detail.append({"id": aid, "result": "fail", "err": "not_indexed"})
            continue
        src = db.asset_abspath(conn, row)
        if not os.path.exists(src):
            n_fail += 1
            detail.append({"id": aid, "name": row["filename"], "result": "fail", "err": "src_missing"})
            continue

        out_dir = os.path.join(dest_dir, row["folder_path"]) if preserve_tree else dest_dir
        os.makedirs(out_dir, exist_ok=True)
        dst = _resolve_conflict(os.path.join(out_dir, target_name(row, naming_mode)), on_conflict)
        if dst is None:
            n_skip += 1
            detail.append({"id": aid, "name": row["filename"], "result": "skip", "err": "name_exists"})
            continue
        try:
            shutil.copy2(src, dst)
            # exFAT 挂载时是 noowners，文件模式一律 700。copy2 会原样带过去，
            # 于是项目目录里躺着一堆 -rwx------ 的素材。落地后按 umask 修正成普通文件。
            os.chmod(dst, 0o666 & ~_umask())
            n_ok += 1
            detail.append({"id": aid, "name": os.path.basename(dst), "result": "ok"})
        except OSError as e:
            n_fail += 1
            detail.append({"id": aid, "name": row["filename"], "result": "fail", "error": str(e)})

    conn.execute(
        "INSERT INTO copy_log (ts, dest_dir, naming_mode, n_ok, n_skip, n_fail, detail_json) "
        "VALUES (?,?,?,?,?,?,?)",
        (time.time(), dest_dir, naming_mode, n_ok, n_skip, n_fail,
         json.dumps(detail, ensure_ascii=False)),
    )
    conn.commit()
    return {"dest_dir": dest_dir, "n_ok": n_ok, "n_skip": n_skip, "n_fail": n_fail,
            "detail": detail}


def recent_destinations(conn, limit=8):
    return [r["dest_dir"] for r in conn.execute(
        "SELECT dest_dir, max(ts) t FROM copy_log GROUP BY dest_dir ORDER BY t DESC LIMIT ?",
        (limit,))]
